﻿<#
	.SYNOPSIS
		Exports AX 2012 server configurations and perform additional operations
		Version 1.0
		Mathieu Tessier
        http://www.mathdax.ca
        https://mathdax.codeplex.com
		
	.DESCRIPTION
        Supports AX 2012 R3
        Please run script from its root folder.
        PowerShell must be run with elevated privileges.
        Prerequisites
        - SQL Client Tools
        - db_owner on business and model databases
        - Local Admin on the AOS servers if you want to stop and start AOS services (optional)
        - Local Admin on the Management Reporter Server if you want to stop and start MR services (optional)
        

	.PARAMETER	file
		Mandatory parameter - creates .XML file containing environment information default path is .\Config\ENV.XML
	.PARAMETER	server
		Mandatory parameter - servername where the Dynamics AX databases reside
	.PARAMETER	database
		Mandatory parameter - business database name of Dynamics AX
#>
param
(
    [string]$server = $(throw '- Need parameter server'),
    [string]$database  = $(throw '- Need parameter database'),
    [string]$file = $(throw '- Need parameter file')
)

$scriptVersion ="1.0"
$databaseModelName = $database+'_model'

Function Test-SQLConnection ($Server,$database) {
    $ConnectionString = "Server=$Server;Integrated Security=true;Database=$database;Connect Timeout=3;"
    
    TRY {
        $SQLConn = new-object ("Data.SqlClient.SqlConnection") $ConnectionString
        $SQLConn.Open()
        
        IF ($SQLConn.State -eq 'Open') {

            $SQLConn.Close();
            Write-Host -ForegroundColor Black -BackgroundColor Green "Pass"
        }
    }
    CATCH 
    {
        $SQLconn.Close();
        Write-Host -BackgroundColor Red -ForegroundColor Black "Fail"
        Exit
    }
}

Function Check-PSElevated {
  $wid=[System.Security.Principal.WindowsIdentity]::GetCurrent()
  $prp=new-object System.Security.Principal.WindowsPrincipal($wid)
  $adm=[System.Security.Principal.WindowsBuiltInRole]::Administrator
  $IsAdmin=$prp.IsInRole($adm)
  if ($IsAdmin)
  {
    Write-Host -ForegroundColor Black -BackgroundColor Green "Pass"
  }
  else
  {
    Write-Host -BackgroundColor Red -ForegroundColor Black "Fail"
    Write-Host "`nPlease run PowerShell with elevated privileges`n"
    Exit
  }

}

Function Check-ServiceStoppedStatus ($runningServer) {
Write-Host -ForegroundColor White "`nStatus Update"
$runningServerCount = $runningServer.count
$maxRepeat = 80
$sleepseconds = 10

do 
    {
        Write-Host -ForegroundColor White "`nServer Running: "$runningServerCount
        Write-Host -ForegroundColor White "Status Refresh Countdown: "$maxRepeat

        for($i=0; $i -lt $runningServer.count; $i++)  
        {  
            $serverName = $runningServer[$i][0]
            $serviceName = $runningServer[$i][1]
            $serviceState = $runningServer[$i][2]

            if ($serviceState -eq "Stopped") 
            {
                Write-Host "-Status Service $serviceName on $serverName " -NoNewline
                Write-Host -ForegroundColor Black -BackgroundColor Green $serviceState
            }
            else
            {
                $serviceCurrentState = Get-Service $serviceName -ComputerName $serverName
                $runningServer[$i][2] = $serviceCurrentState.Status
                $newServiceState = $runningServer[$i][2]

                Write-Host "-Status Service $serviceName on $serverName " -NoNewline

                if ($newServiceState -eq "Stopped") 
                {        
                    $runningServerCount--
                    Write-Host -ForegroundColor Black -BackgroundColor Green $newServiceState
                }
                elseif ($newServiceState -eq "StopPending") 
                {

                    Write-Host -ForegroundColor Black -BackgroundColor Yellow $newServiceState 
                }
                else 
                {
                    $runningServerCount--
                    Write-Host -ForegroundColor Black -BackgroundColor Red $newServiceState 
                }
            }
        }
        $maxRepeat--
        sleep -Seconds $sleepseconds
    }until ($runningServerCount -eq 0 -OR $maxRepeat -eq 0)
}

#VALIDATION CHECKS======================
##FILE VALIDATION=======================

write-host -ForegroundColor White "`nValidation Checks"
Write-Host "Checking Configuration folder " -NoNewline

$configFolder = $PSScriptRoot + '\Config\'
$configFile = $PSScriptRoot + '\Config\' + $file

if (Test-Path $configFolder)
{
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
}
else
{
    Write-Host -BackgroundColor Red -ForegroundColor Black "Not Found"
    Exit
} 


##DATABASE CONNECTIVITY VALIDATION=======================
Write-Host -ForegroundColor White "`nDatabase Connectivity"

Write-Host "-$database "  -NoNewline
Test-SQLConnection $server $database


Write-Host "-$databaseModelName "  -NoNewline
Test-SQLConnection $server $databaseModelName


##MODULE VALIDATION======================
Write-Host "`nChecking SQL Client Tools "  -NoNewline

Push-Location

if (Get-Module -ListAvailable -Name sqlps) 
{
    Import-Module "sqlps" -DisableNameChecking
    Write-Host -ForegroundColor Black -BackgroundColor Green "Pass"
} 
else 
{
    Write-Host -BackgroundColor Red -ForegroundColor Black "Fail"
    Exit
}

#Check PowerShell running with elevated privileges - Start/Stop AOS Services
Write-Host "Checking if PowerShell is running with Elevated Privileges " -NoNewline 
Check-PSElevated


#Environment=================
$environment = Read-Host "`nEnvironment Name ?"

#XML Header=================
Write-Host -ForegroundColor White "`nBuilding XML File"

$xmlDoc = New-Object System.XML.XMLDocument
$xmlRoot = $xmlDoc.AppendChild($xmlDoc.CreateElement("Configuration"));
$xmlRoot.SetAttribute("Version",$scriptVersion)
$xmlRoot.SetAttribute("Environment",$environment)

#Root Comments=============
$xmlRootComment = $xmlDoc.CreateComment("This XML file was auto-generated by the ExportAxConfiguration script. Thus, it is part of a the export/import solutions and can not be used for other purposes. Please report issues to mtessier@hitachi-solutions.com")
$xmlRootElementComment = $xmlRoot.InsertBefore($xmlRootComment,$xmlSQLServerElement)
$xmlRootComment1 = $xmlDoc.CreateComment("General Instructions:  Review the configuration below. Each component can be set to true or false. You can also change the value of fields. e.g You find that your SSRS Server has the wrong description, you can edit the XML file and edit the description")
$xmlRootElementComment = $xmlRoot.InsertBefore($xmlRootComment1,$xmlSQLServerElement)
$xmlRootComment2 = $xmlDoc.CreateComment("Import Process: The import script will read the XML file and import the data in the partition listed in the PARTITION element in the database listed in the DATABASE element. The import script will ignore components/features set to false. e.g NewGUID = false will not generate a new GUID during the import. if a component is set to true but is not defined, the import script will delete the servers in the destination environment and import nothing.")
$xmlRootElementComment = $xmlRoot.InsertBefore($xmlRootComment2,$xmlSQLServerElement)


#SQLServer Element=================
$xmlSQLServerElement = $xmlRoot.AppendChild($xmlDoc.CreateElement("SQLServer"));
$xmlSQLServerNameElement = $xmlSQLServerElement.AppendChild($xmlDoc.CreateElement("NAME"));
$xmlSQLServerNameTextNode = $xmlSQLServerNameElement.AppendChild($xmlDoc.CreateTextNode($server));


#Database Element=================
$xmlDatabasesElement = $xmlRoot.AppendChild($xmlDoc.CreateElement("Databases"));

$result = Invoke-Sqlcmd -Query "SELECT recovery_model_desc AS RecoveryModel FROM sys.databases WHERE name = '$database'" -ServerInstance $server -Database $database
$xmlBusinessDatabaseElement = $xmlDatabasesElement.AppendChild($xmlDoc.CreateElement("BUSINESSDATABASE"));
$xmlBusinessDatabaseNameElement = $xmlBusinessDatabaseElement.AppendChild($xmlDoc.CreateElement("NAME"));
$xmlBusinessDatabaseNameTextNode = $xmlBusinessDatabaseNameElement.AppendChild($xmlDoc.CreateTextNode($database));
$xmlBusinessDatabaseRecModelElement = $xmlBusinessDatabaseElement.AppendChild($xmlDoc.CreateElement("RECOVERYMODEL"));
$xmlBusinessDatabaseRecModelTextNode = $xmlBusinessDatabaseRecModelElement.AppendChild($xmlDoc.CreateTextNode($($result.RecoveryModel)));

$result = Invoke-Sqlcmd -Query "SELECT recovery_model_desc AS RecoveryModel FROM sys.databases WHERE name = '$databaseModelName'" -ServerInstance $server -Database $database
$xmlModelDatabaseElement = $xmlDatabasesElement.AppendChild($xmlDoc.CreateElement("MODELDATABASE"));
$xmlModelDatabaseNameElement = $xmlModelDatabaseElement.AppendChild($xmlDoc.CreateElement("NAME"));
$xmlModelDatabaseNameTextNode = $xmlModelDatabaseNameElement.AppendChild($xmlDoc.CreateTextNode($databaseModelName));
$xmlModelDatabaseRecModelElement = $xmlModelDatabaseElement.AppendChild($xmlDoc.CreateElement("RECOVERYMODEL"));
$xmlModelDatabaseRecModelTextNode = $xmlModelDatabaseRecModelElement.AppendChild($xmlDoc.CreateTextNode($($result.RecoveryModel)));



#Global Element=================
$xmlGlobalElement = $xmlRoot.AppendChild($xmlDoc.CreateElement("Global"));


##Global/Partition
Write-Host "-Partition: "  -NoNewline
$xmlPartitionElement = $xmlGlobalElement.AppendChild($xmlDoc.CreateElement("Partition"));
$xmlPartitionComment = $xmlDoc.CreateComment("The XML file contains the data for the partition listed below. The same partition key must exist in your destination enviroment.")
$xmlPartitionElementComment = $xmlGlobalElement.InsertBefore($xmlPartitionComment,$xmlPartitionElement)

#Check how many partitions are in AX
$result = Invoke-Sqlcmd -Query "SELECT COUNT (*) As COUNT FROM PARTITIONS" -ServerInstance $server -Database $database


if ($($result.COUNT) -ne 0)
{
    if ($($result.COUNT) -ge 2)
    {
        Write-Host -ForegroundColor Black -Backgroundcolor Yellow "Multiple Partitions Detected "
        $result = Invoke-Sqlcmd -Query "SELECT PARTITIONKEY FROM PARTITIONS" -ServerInstance $server -Database $database
    
         Write-Host -ForegroundColor White "`nPartition Found:"

        foreach($item in $result)
        {
            Write-Host -ForeGround White "$($Item.PARTITIONKEY)"
        }
    
        $partitionkey = Read-Host "`nType the partition name you want to export"
    
        $result = Invoke-Sqlcmd -Query "SELECT RECID, PARTITIONKEY FROM PARTITIONS WHERE PARTITIONKEY='$partitionkey'" -ServerInstance $server -Database $database

        $partitionid = $result.RECID
        $partitionkey = $result.PARTITIONKEY
    }
    elseif ($($result.COUNT) -eq 1)
    {
        Write-Host -ForegroundColor Black -BackgroundColor Green "Found"

        $result = Invoke-Sqlcmd -Query "SELECT RECID, PARTITIONKEY FROM PARTITIONS" -ServerInstance $server -Database $database

    }
    
    $partitionid = $result.RECID
    $partitionkey = $result.PARTITIONKEY

    $xmlPartitionKeyElement = $xmlPartitionElement.AppendChild($xmlDoc.CreateElement("PARTITIONKEY"));
    $xmlPartitionKeyTextNode = $xmlPartitionKeyElement.AppendChild($xmlDoc.CreateTextNode($($result.PARTITIONKEY)));
    $xmlPartitionIDElement = $xmlPartitionElement.AppendChild($xmlDoc.CreateElement("PARTITIONID"));
    $xmlPartitionIDTextNode = $xmlPartitionIDElement.AppendChild($xmlDoc.CreateTextNode($($result.RECID)));
}
else
{
  Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found"
  Exit
}


##Global/GUID===================

$xmlNewGUIDElement = $xmlGlobalElement.AppendChild($xmlDoc.CreateElement("GUID"));
$xmlNewGUIDElement.SetAttribute("NewGUID","True")
$xmlNewGUIDComment = $xmlDoc.CreateComment("The feature will generate a new GUID during the import. It is recommended to set it to true")
$xmlNewGUIDElementComment = $xmlGlobalElement.InsertBefore($xmlNewGUIDComment,$xmlNewGUIDElement)

$xmlGUIDElement = $xmlNewGUIDElement.AppendChild($xmlDoc.CreateElement("GUID"));
$xmlGUIDTextNode = $xmlGUIDElement.AppendChild($xmlDoc.CreateTextNode('00000000-0000-0000-0000-000000000000'));

##Global/DATAAREAIDLITERAL

Write-Host "-Data Area ID Literal: "  -NoNewline

$xmlDataAreaIDLiteralElement = $xmlGlobalElement.AppendChild($xmlDoc.CreateElement("DataAreaIDLiteral"));
$xmlDataAreaIDLiteralElement.SetAttribute("UpdateDataAreaIDLiteral","True")

$result = Invoke-Sqlcmd -Query "(SELECT VALUE from SYSGLOBALCONFIGURATION WHERE NAME = 'DATAAREAIDLITERAL')" -ServerInstance $server -Database $database

if ($($result.VALUE))
{
    $xmlDataLiteralElement = $xmlDataAreaIDLiteralElement.AppendChild($xmlDoc.CreateElement("DATAAREAIDLITERAL"));
    $xmlDataLiteralElementTextNode = $xmlDataLiteralElement.AppendChild($xmlDoc.CreateTextNode($($result.VALUE)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

##Global/PARTITIONLITERAL

Write-Host "-Partition Literal: "  -NoNewline

$xmlPartitionLiteralElement = $xmlGlobalElement.AppendChild($xmlDoc.CreateElement("PartitionLiteral"));
$xmlPartitionLiteralElement.SetAttribute("UpdatePartitionLiteral","True")

$result = Invoke-Sqlcmd -Query "(SELECT VALUE from SYSGLOBALCONFIGURATION WHERE NAME = 'PARTITIONLITERAL')" -ServerInstance $server -Database $database

if ($($result.VALUE))
{
    $xmlPartitionValueElement = $xmlPartitionLiteralElement.AppendChild($xmlDoc.CreateElement("PARTITIONLITERAL"));
    $xmlPartitionValueElementTextNode = $xmlPartitionValueElement.AppendChild($xmlDoc.CreateTextNode($($result.VALUE)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}


#Table Element=================

$xmlTablesElement = $xmlRoot.AppendChild($xmlDoc.CreateElement("Tables"));
$xmlEventInboxElement = $xmlTablesElement.AppendChild($xmlDoc.CreateElement("EventInbox"));
$xmlEventInboxElement.SetAttribute("TruncateEventInbox","True")
$xmlDatabaseLogsElement = $xmlTablesElement.AppendChild($xmlDoc.CreateElement("SysDatabaseLog"));
$xmlDatabaseLogsElement.SetAttribute("TruncateSysDatabaseLog","True")
$xmlExceptionLogsElement = $xmlTablesElement.AppendChild($xmlDoc.CreateElement("SysExceptionTable"));
$xmlExceptionLogsElement.SetAttribute("TruncateSysExceptionTable","True")
$xmlSysClientSessionsElement = $xmlTablesElement.AppendChild($xmlDoc.CreateElement("SysClientSessions"));
$xmlSysClientSessionsElement.SetAttribute("TruncateSysClientSessions","True")
$xmlSysServerSessionsElement = $xmlTablesElement.AppendChild($xmlDoc.CreateElement("SysServerSessions"));
$xmlSysServerSessionsElement.SetAttribute("TruncateSysServerSessions","True")
$xmlSysServerConfigElement = $xmlTablesElement.AppendChild($xmlDoc.CreateElement("SysServerConfig"));
$xmlSysServerConfigElement.SetAttribute("TruncateSysServerConfig","True")
$xmlSysClusterConfigElement = $xmlTablesElement.AppendChild($xmlDoc.CreateElement("SysClusterConfig"));
$xmlSysClusterConfigElement.SetAttribute("TruncateSysClusterConfig","True")
$xmlTableComment = $xmlDoc.CreateComment("This feature will truncate the tables below during the import.")
$xmlTableElementComment = $xmlTablesElement.InsertBefore($xmlTableComment,$xmlEventInboxElement)

#Batch Element=================

$xmlBatchElement = $xmlRoot.AppendChild($xmlDoc.CreateElement("Batch"));
$xmlBatchHistoryElement = $xmlBatchElement.AppendChild($xmlDoc.CreateElement("BatchHistory"));
$xmlBatchHistoryElement.SetAttribute("TruncateBatchHistory","True")
$xmlBatchServerGroupElement = $xmlBatchElement.AppendChild($xmlDoc.CreateElement("BatchServerGroup"));
$xmlBatchServerGroupElement.SetAttribute("TruncateBatchServerGroup","True")
$xmlBatchServerConfigElement = $xmlBatchElement.AppendChild($xmlDoc.CreateElement("BatchServerConfig"));
$xmlBatchServerConfigElement.SetAttribute("TruncateBatchServerConfig","True")
$xmlBatchJobHistoryElement = $xmlBatchElement.AppendChild($xmlDoc.CreateElement("BatchJobHistory"));
$xmlBatchJobHistoryElement.SetAttribute("TruncateBatchJobHistory","True")
$xmlBatchStatusElement = $xmlBatchElement.AppendChild($xmlDoc.CreateElement("BatchStatus"));
$xmlBatchStatusElement.SetAttribute("UpdateBatchStatus","True")
$xmlBatchStatusComment = $xmlDoc.CreateComment("This feature deletes all batch jobs with the status ENDED or CANCELLED and will change the batch jobs status WAITING, READY OR CANCELLING to WITHHOLD. It is recommended to set to True unless you are troubleshooting batch jobs.")
$xmlBatchStatusElementComment = $xmlBatchElement.InsertBefore($xmlBatchStatusComment,$xmlBatchStatusElement)

#Accounts Element======================
$xmlAccountsElement = $xmlRoot.AppendChild($xmlDoc.CreateElement("Accounts"));

##Accounts/Admin======================

Write-Host "-Admin User: "  -NoNewline
$xmlAdminElement = $xmlAccountsElement.AppendChild($xmlDoc.CreateElement("Admin"));
$xmlAdminElement.SetAttribute("UpdateAdminUser","True")
$xmlAdminComment = $xmlDoc.CreateComment("This feature allows you to update the admin user. Only one user with the ID 'ADMIN' can exist per partition. This section can not be empty and set to True. You should have at least one user with the ID 'ADMIN'")
$xmlAdminElementComment = $xmlAccountsElement.InsertBefore($xmlAdminComment,$xmlAdminElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT (*) As COUNT FROM USERINFO WHERE ID = 'Admin' AND PARTITION =$partitionid" -ServerInstance $server -Database $database

if ($($result.COUNT) -eq 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT SID, NETWORKDOMAIN, NETWORKALIAS FROM USERINFO WHERE ID = 'Admin' AND PARTITION =$partitionid" -ServerInstance $server -Database $database

    foreach($item in $result){
      $xmlAdminSIDElement = $xmlAdminElement.AppendChild($xmlDoc.CreateElement("SID"));
      $xmlAdminSIDTextNode = $xmlAdminSIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.SID)));
      $xmlAdminNetworkDomainElement = $xmlAdminElement.AppendChild($xmlDoc.CreateElement("NETWORKDOMAIN"));
      $xmlAdminNetworkDomainTextNode = $xmlAdminNetworkDomainElement.AppendChild($xmlDoc.CreateTextNode($($Item.NETWORKDOMAIN)));
      $xmlAdminNetworkAliasElement = $xmlAdminElement.AppendChild($xmlDoc.CreateElement("NETWORKALIAS"));
      $xmlAdminNetworkAliasTextNode = $xmlAdminNetworkAliasElement.AppendChild($xmlDoc.CreateTextNode($($Item.NETWORKALIAS)));
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found"
}

 ##Accounts/BCPROXY======================

Write-Host "-BCProxy: "  -NoNewline
$xmlBCProxyElement = $xmlAccountsElement.AppendChild($xmlDoc.CreateElement("BCProxy"));
$xmlBCProxyElement.SetAttribute("UpdateBCProxyAccount","True")
$xmlBCProxyComment = $xmlDoc.CreateComment("The feature updates the BCProxy Account. If empty and set to TRUE, then the bcproxy Account will be deleted during the import")
$xmlBCProxyElementComment = $xmlAccountsElement.InsertAfter($xmlBCProxyComment,$xmlAdminElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT (*) As COUNT FROM SYSBCPROXYUSERAccount" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT SID, NETWORKDOMAIN, NETWORKALIAS FROM SYSBCPROXYUSERAccount" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlBCProxySIDElement = $xmlBCProxyElement.AppendChild($xmlDoc.CreateElement("SID"));
      $xmlBCProxySIDTextNode = $xmlBCProxySIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.SID)));
      $xmlBCProxyNetworkDomainElement = $xmlBCProxyElement.AppendChild($xmlDoc.CreateElement("NETWORKDOMAIN"));
      $xmlBCProxyNetworkDomainTextNode = $xmlBCProxyNetworkDomainElement.AppendChild($xmlDoc.CreateTextNode($($Item.NETWORKDOMAIN)));
      $xmlBCProxyNetworkAliasElement = $xmlBCProxyElement.AppendChild($xmlDoc.CreateElement("NETWORKALIAS"));
      $xmlBCProxyNetworkAliasTextNode = $xmlBCProxyNetworkAliasElement.AppendChild($xmlDoc.CreateTextNode($($Item.NETWORKALIAS))); 
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

 ##Accounts/MR Integration Account======================

Write-Host "-MR Integration Account: "  -NoNewline
$xmlMRintElement = $xmlAccountsElement.AppendChild($xmlDoc.CreateElement("MRIntegration"));
$xmlMRintElement.SetAttribute("UpdateMRIntegrationAccount","True")
$xmlMRintComment = $xmlDoc.CreateComment("The feature updates the MR Integration Account Account. If empty and set to TRUE, then the MR Account will be deleted during the import")
$xmlMRintElementComment = $xmlAccountsElement.InsertAfter($xmlMRintComment,$xmlBCProxyElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT (*) AS COUNT FROM USERINFO WHERE ID ='MRint'" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT NAME,SID, NETWORKDOMAIN, NETWORKALIAS FROM USERINFO WHERE ID ='MRint'" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlMRintNameElement = $xmlMRintElement.AppendChild($xmlDoc.CreateElement("NAME"));
      $xmlMRintNameTextNode = $xmlMRintNameElement.AppendChild($xmlDoc.CreateTextNode($($Item.NAME)));
      $xmlMRintSIDElement = $xmlMRintElement.AppendChild($xmlDoc.CreateElement("SID"));
      $xmlMRintSIDTextNode = $xmlMRintSIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.SID)));
      $xmlMRintNetworkDomainElement = $xmlMRintElement.AppendChild($xmlDoc.CreateElement("NETWORKDOMAIN"));
      $xmlMRintNetworkDomainTextNode = $xmlMRintNetworkDomainElement.AppendChild($xmlDoc.CreateTextNode($($Item.NETWORKDOMAIN)));
      $xmlMRintNetworkAliasElement = $xmlMRintElement.AppendChild($xmlDoc.CreateElement("NETWORKALIAS"));
      $xmlMRintNetworkAliasTextNode = $xmlMRintNetworkAliasElement.AppendChild($xmlDoc.CreateTextNode($($Item.NETWORKALIAS))); 
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

##Accounts/Workflow======================

Write-Host "-Workflow: "  -NoNewline
$xmlWorkflowElement = $xmlAccountsElement.AppendChild($xmlDoc.CreateElement("Workflow"));
$xmlWorkflowElement.SetAttribute("UpdateWorkflowAccount","True")
$xmlWorkflowComment = $xmlDoc.CreateComment("The feature update the workflow user Account. If empty and set to TRUE, then the workflow Account and workflow batches will be deleted")
$xmlWorkflowElementComment = $xmlAccountsElement.InsertAfter($xmlWorkflowComment,$xmlMRintElement)


$result = Invoke-Sqlcmd -Query "SELECT COUNT (*) AS COUNT FROM SYSWORKFLOWPARAMETERS WHERE PARTITION =$partitionid AND EXECUTIONUSERID !=''" -ServerInstance $server -Database $database

if ($($result.COUNT) -eq 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT EXECUTIONUSERID FROM SYSWORKFLOWPARAMETERS WHERE PARTITION =$partitionid" -ServerInstance $server -Database $database
    $workflowUserID = $($result.EXECUTIONUSERID)

    $result = Invoke-Sqlcmd -Query "SELECT ID, NAME, SID, NETWORKDOMAIN, NETWORKALIAS FROM USERINFO WHERE PARTITION =$partitionid AND ID = '$workflowUserID'" -ServerInstance $server -Database $database

    $workflowName = $result.NAME
    $workflowName = $workflowName.trim()

    $xmlWorkflowIDElement = $xmlWorkflowElement.AppendChild($xmlDoc.CreateElement("ID"));
    $xmlWorkflowIDTextNode = $xmlWorkflowIDElement.AppendChild($xmlDoc.CreateTextNode($($result.ID)));
    $xmlWorkflowNameElement = $xmlWorkflowElement.AppendChild($xmlDoc.CreateElement("NAME"));
    $xmlWorkflowNameTextNode = $xmlWorkflowNameElement.AppendChild($xmlDoc.CreateTextNode($($workflowName)));
    $xmlWorkflowSIDElement = $xmlWorkflowElement.AppendChild($xmlDoc.CreateElement("SID"));
    $xmlWorkflowSIDTextNode = $xmlWorkflowSIDElement.AppendChild($xmlDoc.CreateTextNode($($result.SID)));
    $xmlWorkflowNetworkDomainElement = $xmlWorkflowElement.AppendChild($xmlDoc.CreateElement("NETWORKDOMAIN"));
    $xmlWorkflowNetworkDomainTextNode = $xmlWorkflowNetworkDomainElement.AppendChild($xmlDoc.CreateTextNode($($result.NETWORKDOMAIN)));
    $xmlWorkflowNetworkAliasElement = $xmlWorkflowElement.AppendChild($xmlDoc.CreateElement("NETWORKALIAS"));
    $xmlWorkflowNetworkAliasTextNode = $xmlWorkflowNetworkAliasElement.AppendChild($xmlDoc.CreateTextNode($($result.NETWORKALIAS)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}



#SERVERS ELEMENT======================
$xmlServersElement = $xmlRoot.AppendChild($xmlDoc.CreateElement("Servers"));

#SERVERS/SSRS======================

Write-Host "-SSRS Servers: "  -NoNewline

$xmlSSRSServersElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("SSRSServers"));
$xmlSSRSServersElement.SetAttribute("AddSSRSServers","True")
$xmlSSRSComment = $xmlDoc.CreateComment("The features imports SSRS Servers. Multiple SSRS Servers can be specified. Existing SSRS servers are deleted during the import process.")
$xmlSSRSElementComment = $xmlServersElement.InsertBefore($xmlSSRSComment,$xmlSSRSServersElement)

$result = Invoke-Sqlcmd -Query "SELECT  COUNT(*) AS COUNT FROM SRSSERVERS" -ServerInstance $server -Database $database
if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT CONFIGURATIONID,SERVERID,SERVERURL,ISDEFAULTREPORTLIBRARYSERVER,AXAPTAREPORTFOLDER,DESCRIPTION,REPORTMANAGERURL,SERVERINSTANCE,AOSID,ISSHAREPOINTINTEGRATED FROM SRSSERVERS" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlSSRSServerElement = $xmlSSRSServersElement.AppendChild($xmlDoc.CreateElement("SSRSServer"));
      $xmlSSRSConfigIDElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("CONFIGURATIONID"));
      $xmlSSRSConfigIDTextNode = $xmlSSRSConfigIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.CONFIGURATIONID)));
      $xmlSSRSServerIDElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("SERVERID"));
      $xmlSSRSServerIDTextNode = $xmlSSRSServerIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.SERVERID)));
      $xmlSSRSDescriptionElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("DESCRIPTION"));
      $xmlSSRSDescriptionTextNode = $xmlSSRSDescriptionElement.AppendChild($xmlDoc.CreateTextNode($($Item.DESCRIPTION)));
      $xmlSSRSServerURLElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("SERVERURL"));
      $xmlSSRSServerURLTextNode = $xmlSSRSServerURLElement.AppendChild($xmlDoc.CreateTextNode($($Item.SERVERURL)));
      $xmlSSRSReportURLElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("REPORTMANAGERURL"));
      $xmlSSRSReportURLTextNode = $xmlSSRSReportURLElement.AppendChild($xmlDoc.CreateTextNode($($Item.REPORTMANAGERURL)));
      $xmlSSRSReportFolderElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("AXAPTAREPORTFOLDER"));
      $xmlSSRSReportFolderTextNode = $xmlSSRSReportFolderElement.AppendChild($xmlDoc.CreateTextNode($($Item.AXAPTAREPORTFOLDER)));
      $xmlSSRSIsDefaultElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("ISDEFAULTREPORTLIBRARYSERVER"));
      $xmlSSRSIsDefaultTextNode = $xmlSSRSIsDefaultElement.AppendChild($xmlDoc.CreateTextNode($($Item.ISDEFAULTREPORTLIBRARYSERVER)));
      $xmlSSRSServerInstanceElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("SERVERINSTANCE"));
      $xmlSSRSServerInstanceTextNode = $xmlSSRSServerInstanceElement.AppendChild($xmlDoc.CreateTextNode($($Item.SERVERINSTANCE)));
      $xmlSSRSSharePointElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("ISSHAREPOINTINTEGRATED"));
      $xmlSSRSSharePointTextNode = $xmlSSRSSharePointElement.AppendChild($xmlDoc.CreateTextNode($($Item.ISSHAREPOINTINTEGRATED)));
      $xmlSSRSAOSIDElement = $xmlSSRSServerElement.AppendChild($xmlDoc.CreateElement("AOSID"));
      $xmlSSRSAOSIDTextNode = $xmlSSRSAOSIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.AOSID)));
    }
      Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
  Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

##SERVERS/HELP======================

Write-Host "-Help Server: "  -NoNewline
$xmlHelpServerElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("HelpServer"));
$xmlHelpServerElement.SetAttribute("UpdateHelpServerURL","True")
$xmlHelpServerComment = $xmlDoc.CreateComment("The feature updates the Help Server URL. If empty and set to TRUE, then the Help Server will be deleted")
$xmlHelpServerElementComment = $xmlServersElement.InsertAfter($xmlHelpServerComment,$xmlSSRSServersElement)

$result = Invoke-Sqlcmd -Query "SELECT VALUE FROM SYSGLOBALCONFIGURATION WHERE NAME = 'HelpServerLocation'" -ServerInstance $server -Database $database

if ($($result.VALUE) -ne '')
{
    $xmlHelpServerURLElement = $xmlHelpServerElement.AppendChild($xmlDoc.CreateElement("URL"));
    $xmlHelpServerURLTextNode = $xmlHelpServerURLElement.AppendChild($xmlDoc.CreateTextNode($($result.VALUE)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

##SERVERS/SCOM======================

Write-Host "-SCOM AOS: "  -NoNewline
$xmlSCOMElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("SCOM"));
$xmlSCOMElement.SetAttribute("UpdateSCOMAOS","True")
$xmlSCOMComment = $xmlDoc.CreateComment("The feature updates the SCOM AOS. If empty and set to TRUE, then the SCOM AOS will be deleted")
$xmlSCOMElementComment = $xmlServersElement.InsertAfter($xmlSCOMComment,$xmlHelpServerElement)

$result = Invoke-Sqlcmd -Query "SELECT VALUE FROM SYSGLOBALCONFIGURATION WHERE NAME = 'SCOMPERFORMANCEAOS'" -ServerInstance $server -Database $database

if ($($result.VALUE))
{
    $xmlSCOMAOSElement = $xmlSCOMElement.AppendChild($xmlDoc.CreateElement("AOS"));
    $xmlSCOMAOSTextNode = $xmlSCOMAOSElement.AppendChild($xmlDoc.CreateTextNode($($result.VALUE)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

##SERVERS/DIXF======================

Write-Host "-DIXF: "  -NoNewline
$xmlDIXFElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("DIXF"));
$xmlDIXFElement.SetAttribute("UpdateDIXFSharedPath","True")
$xmlDIXFComment = $xmlDoc.CreateComment("The feature updates the DIXF shared path. If empty and set to TRUE, then the DIXF shared path will be deleted")
$xmlDIXFElementComment = $xmlServersElement.InsertAfter($xmlDIXFComment,$xmlSCOMElement)

$result = Invoke-Sqlcmd -Query "SELECT SHAREDFOLDERPATH FROM DMFPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

if ($($result.SHAREDFOLDERPATH) -ne '')
{

    $xmlDIXFPathElement = $xmlDIXFElement.AppendChild($xmlDoc.CreateElement("SHAREDFOLDERPATH"));
    $xmlDIXFPathTextNode = $xmlDIXFPathElement.AppendChild($xmlDoc.CreateTextNode($($result.SHAREDFOLDERPATH)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}


##SERVERS/SMTP======================

Write-Host "-SMTP Server: "  -NoNewline
$xmlSmtpServerElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("SMTPServer"));
$xmlSmtpServerElement.SetAttribute("UpdateSMTPServer","True")
$xmlSmtpServerComment = $xmlDoc.CreateComment("The feature updates the STMP Server. If empty and set to TRUE, then the SMTP Server will be deleted")
$xmlSmtpServerElementComment = $xmlServersElement.InsertAfter($xmlSmtpServerComment,$xmlDIXFElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM SYSEMAILPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

if ($($result.COUNT) -eq 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT * FROM SYSEMAILPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

    $xmlSMTPServerNameElement = $xmlSMTPServerElement.AppendChild($xmlDoc.CreateElement("SMTPRELAYSERVERNAME"));
    $xmlSMTPServerNameTextNode = $xmlSMTPServerNameElement.AppendChild($xmlDoc.CreateTextNode($($result.SMTPRELAYSERVERNAME)));
    $xmlSMTPPortElement = $xmlSmtpServerElement.AppendChild($xmlDoc.CreateElement("SMTPPORTNUMBER"));
    $xmlSMTPPortTextNode = $xmlSMTPPortElement.AppendChild($xmlDoc.CreateTextNode($($result.SMTPPORTNUMBER)));
    $xmlSMTPIPElement = $xmlSmtpServerElement.AppendChild($xmlDoc.CreateElement("SMTPSERVERIPADDRESS"));
    $xmlSMTPIPTextNode = $xmlSMTPIPElement.AppendChild($xmlDoc.CreateTextNode($($result.SMTPSERVERIPADDRESS)));
    $xmlSMTPMaxElement = $xmlSmtpServerElement.AppendChild($xmlDoc.CreateElement("MAXEMAILATTACHMENTSIZE"));
    $xmlSMTPMaxTextNode = $xmlSMTPMaxElement.AppendChild($xmlDoc.CreateTextNode($($result.MAXEMAILATTACHMENTSIZE)));
    $xmlSMTPNtlmElement = $xmlSmtpServerElement.AppendChild($xmlDoc.CreateElement("NTLM"));
    $xmlSMTPNtlmTextNode = $xmlSMTPNtlmElement.AppendChild($xmlDoc.CreateTextNode($($result.NTLM)));


    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

##SERVERS/SSAS======================

Write-Host "-SSAS Servers: "  -NoNewline

$xmlSSASServersElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("SSASServers"));
$xmlSSASServersElement.SetAttribute("UpdateSSASServer","True")
$xmlSSASServersComment = $xmlDoc.CreateComment("The feature updates the SSAS Servers. If empty and set to TRUE, then the SSAS Servers will be deleted.For concistency, you should enable or disable both SSAS Components (Servers & Databases)")
$xmlSSASServersElementComment = $xmlServersElement.InsertAfter($xmlSSASServersComment,$xmlSMTPServerElement)

$result = Invoke-Sqlcmd -Query "SELECT  COUNT(*) AS COUNT FROM BIANALYSISSERVER" -ServerInstance $server -Database $database
if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT * FROM BIANALYSISSERVER WHERE PARTITIONS=$partitionid" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlSSASServerElement = $xmlSSASServersElement.AppendChild($xmlDoc.CreateElement("SSASServer"));
      $xmlSSASServerElement.SetAttribute("SERVERNAME",$($Item.SERVERNAME))
      $xmlSSASDescriptionElement = $xmlSSASServerElement.AppendChild($xmlDoc.CreateElement("DESCRIPTION"));
      $xmlSSASDescriptionTextNode = $xmlSSASDescriptionElement.AppendChild($xmlDoc.CreateTextNode($($Item.DESCRIPTION)));
      $xmlSSASIsDefaultElement = $xmlSSASServerElement.AppendChild($xmlDoc.CreateElement("ISDEFAULT"));
      $xmlSSASIsDefaultTextNode = $xmlSSASIsDefaultElement.AppendChild($xmlDoc.CreateTextNode($($Item.ISDEFAULT)));
      $xmlSSASIsValidElement = $xmlSSASServerElement.AppendChild($xmlDoc.CreateElement("ISVALID"));
      $xmlSSASIsValidTextNode = $xmlSSASIsValidElement.AppendChild($xmlDoc.CreateTextNode($($Item.ISVALID)));
      $xmlSSASDefaultDBElement = $xmlSSASServerElement.AppendChild($xmlDoc.CreateElement("DEFAULTDATABASE"));
      $xmlSSASDefaultDBTextNode = $xmlSSASDefaultDBElement.AppendChild($xmlDoc.CreateTextNode($($Item.DEFAULTDATABASE)));
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

##SERVERS/SSAS Databases======================

Write-Host "-SSAS Databases: "  -NoNewline

$xmlSSASDatabasesElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("SSASDatabases"));
$xmlSSASDatabasesElement.SetAttribute("UpdateSSASDatabase","True")
$xmlSSASDatabasesComment = $xmlDoc.CreateComment("The feature updates the SSAS Servers. If empty and set to TRUE, then SSAS Databases will be deleted. For concistency, you should enable or disable both SSAS Components (Servers & Databases)")
$xmlSSASDatabasesElementComment = $xmlServersElement.InsertAfter($xmlSSASDatabasesComment,$xmlSSASServersElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM BIANALYSISSERVICESDATABASE bid, BIANALYSISSERVER bis WHERE bid.ANALYSISSERVICESDATABASENAME != '' AND bid.BIANALYSISSERVER = bis.RECID AND bid.PARTITIONS = $partitionid" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT bid.ANALYSISSERVICESDATABASENAME, bid.ISDEFAULT, bis.SERVERNAME FROM BIANALYSISSERVICESDATABASE bid, BIANALYSISSERVER bis WHERE bid.ANALYSISSERVICESDATABASENAME != '' AND bid.BIANALYSISSERVER = bis.RECID AND bid.PARTITIONS = $partitionid" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlSSASDatabaseElement = $xmlSSASDatabasesElement.AppendChild($xmlDoc.CreateElement("SSASDatabase"));
      $xmlSSASDatabaseNameElement = $xmlSSASDatabaseElement.AppendChild($xmlDoc.CreateElement("ANALYSISSERVICESDATABASENAME"));
      $xmlSSASDatabaseNameTextNode = $xmlSSASDatabaseNameElement.AppendChild($xmlDoc.CreateTextNode($($Item.ANALYSISSERVICESDATABASENAME)));
      $xmlSSASIsDefaultElement = $xmlSSASDatabaseElement.AppendChild($xmlDoc.CreateElement("ISDEFAULT"));
      $xmlSSASIsDefaultNameTextNode = $xmlSSASIsDefaultElement.AppendChild($xmlDoc.CreateTextNode($($Item.ISDEFAULT)));
      $xmlSSASServerNameElement = $xmlSSASDatabaseElement.AppendChild($xmlDoc.CreateElement("SERVERNAME"));
      $xmlSSASServerNameTextNode = $xmlSSASServerNameElement.AppendChild($xmlDoc.CreateTextNode($($Item.SERVERNAME)));
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
  Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

##SERVERS/BI Configuration======================

Write-Host "-BI Configuration: "  -NoNewline
$xmlBIConfigElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("BICONFIG"));
$xmlBIConfigElement.SetAttribute("UpdateBIConfig","True")
$xmlBIConfigComment = $xmlDoc.CreateComment("The feature updates the BI configuration. If empty and set to TRUE, then the BI Configuration will be deleted")
$xmlBIConfigElementComment = $xmlServersElement.InsertAfter($xmlBIConfigComment,$xmlSSASDatabasesElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM BICONFIGURATION WHERE RECID=$partitionid" -ServerInstance $server -Database $database

if ($($result.COUNT) -eq 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT * FROM BICONFIGURATION WHERE RECID=$partitionid" -ServerInstance $server -Database $database

    $xmlBIProjectPathElement = $xmlBIConfigElement.AppendChild($xmlDoc.CreateElement("PROJECTPATH"));
    $xmlBIProjectPathTextNode = $xmlBIProjectPathElement.AppendChild($xmlDoc.CreateTextNode($($result.PROJECTPATH)));
    $xmlBIDatasourceElement = $xmlBIConfigElement.AppendChild($xmlDoc.CreateElement("DATASOURCENAME"));
    $xmlBIDatasourceTextNode = $xmlBIDatasourceElement.AppendChild($xmlDoc.CreateTextNode($($result.DATASOURCENAME)));
    $xmlBIConnectStringElement = $xmlBIConfigElement.AppendChild($xmlDoc.CreateElement("CONNECTIONSTRING"));
    $xmlBIConnectStringTextNode = $xmlBIConnectStringElement.AppendChild($xmlDoc.CreateTextNode($($result.CONNECTIONSTRING)));
    $xmlBILogFilePathElement = $xmlBIConfigElement.AppendChild($xmlDoc.CreateElement("LOGFILEPATH"));
    $xmlBILogFilePathTextNode = $xmlBILogFilePathElement.AppendChild($xmlDoc.CreateTextNode($($result.LOGFILEPATH)));


    $xmlBIProjectFileNameElement = $xmlBIConfigElement.AppendChild($xmlDoc.CreateElement("PROJECTFILENAME"));
    $xmlBIProjectFileNameTextNode = $xmlBIProjectFileNameElement.AppendChild($xmlDoc.CreateTextNode($($result.PROJECTFILENAME)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

##SERVERS/EP======================

Write-Host "-EP Sites: "  -NoNewline

$xmlEPSitesElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("EPSites"));
$xmlEPSitesElement.SetAttribute("UpdateEPSite","True")
$xmlEPSitesComment = $xmlDoc.CreateComment("The feature updates the EP Sites. If empty and set to TRUE, then EP Sites will be deleted.")
$xmlEPSitesElementComment = $xmlServersElement.InsertAfter($xmlEPSitesComment,$xmlBIConfigElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM EPWEBSITEPARAMETERS WHERE PARTITIONKEY = '$partitionkey'" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT * FROM EPWEBSITEPARAMETERS WHERE PARTITIONKEY = '$partitionkey'" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlEPSiteElement = $xmlEPSitesElement.AppendChild($xmlDoc.CreateElement("EPSite"));
      $xmlEPInternalURLElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("INTERNALURL"));
      $xmlEPInternalURLElementTextNode = $xmlEPInternalURLElement.AppendChild($xmlDoc.CreateTextNode($($Item.INTERNALURL)));
      $xmlEPTypeElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("TYPE"));
      $xmlEPTypeElementTextNode = $xmlEPTypeElement.AppendChild($xmlDoc.CreateTextNode($($Item.TYPE)));
      $xmlEPSiteIDElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("SITEID"));
      $xmlEPSiteIDElementTextNode = $xmlEPSiteIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.SITEID)));
      $xmlEPAnonymousElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("ANONYMOUSACCESS"));
      $xmlEPAnonymousElementTextNode = $xmlEPAnonymousElement.AppendChild($xmlDoc.CreateTextNode($($Item.ANONYMOUSACCESS)));
      $xmlEPExternalURLElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("EXTERNALURL"));
      $xmlEPExternalURLElementTextNode = $xmlEPExternalURLElement.AppendChild($xmlDoc.CreateTextNode($($Item.EXTERNALURL)));
      $xmlEPEncryptionElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("ENABLEENCRYPTION"));
      $xmlEPEncryptionElementTextNode = $xmlEPEncryptionElement.AppendChild($xmlDoc.CreateTextNode($($Item.ENABLEENCRYPTION)));
      $xmlEPEncryptionExpirationElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("ENCRYPTIONEXPIRATIONINTERVAL"));
      $xmlEPEncryptionExpirationElementTextNode = $xmlEPEncryptionExpirationElement.AppendChild($xmlDoc.CreateTextNode($($Item.ENCRYPTIONEXPIRATIONINTERVAL)));    
      $xmlEPImageSizeElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("IMAGESIZE"));
      $xmlEPImageSizeElementTextNode = $xmlEPImageSizeElement.AppendChild($xmlDoc.CreateTextNode($($Item.IMAGESIZE)));
      $xmlEPImageSizeSmallElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("IMAGESIZESMALL"));
      $xmlEPImageSizeSmallElementTextNode = $xmlEPImageSizeSmallElement.AppendChild($xmlDoc.CreateTextNode($($Item.IMAGESIZESMALL)));
      $xmlEPImageSizeLargeElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("IMAGESIZELARGE"));
      $xmlEPImageSizeLargeElementTextNode = $xmlEPImageSizeLargeElement.AppendChild($xmlDoc.CreateTextNode($($Item.IMAGESIZELARGE)));
      $xmlEPImageRatioElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("IMAGERATIO"));
      $xmlEPImageRatioElementTextNode = $xmlEPImageRatioElement.AppendChild($xmlDoc.CreateTextNode($($Item.IMAGERATIO)));
      $xmlEPCompanyElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("COMPANYINDEPENDENT"));
      $xmlEPCompanyElementTextNode = $xmlEPCompanyElement.AppendChild($xmlDoc.CreateTextNode($($Item.COMPANYINDEPENDENT)));
      $xmlEPLanguageElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("LANGUAGE"));
      $xmlEPLanguageElementTextNode = $xmlEPLanguageElement.AppendChild($xmlDoc.CreateTextNode($($Item.LANGUAGE)));
      $xmlEPSiteInstallElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("SITEINSTALLATIONTYPE"));
      $xmlEPSiteInstallElementTextNode = $xmlEPSiteInstallElement.AppendChild($xmlDoc.CreateTextNode($($Item.SITEINSTALLATIONTYPE)));
      $xmlEPDefaultReportElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("USEDEFAULTREPORTSERVER"));
      $xmlEPDefaultReportElementTextNode = $xmlEPDefaultReportElement.AppendChild($xmlDoc.CreateTextNode($($Item.USEDEFAULTREPORTSERVER)));
      $xmlEPReportIDElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("REPORTSERVERCONFIGURATIONID"));
      $xmlEPReportIDElementTextNode = $xmlEPReportIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.REPORTSERVERCONFIGURATIONID)));
      $xmlEPPartitionElement = $xmlEPSiteElement.AppendChild($xmlDoc.CreateElement("PARTITIONINDEPENDENT"));
      $xmlEPPartitionElementTextNode = $xmlEPPartitionElement.AppendChild($xmlDoc.CreateTextNode($($Item.PARTITIONINDEPENDENT)));
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
  Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

##SERVERS/EP Parameters======================

Write-Host "-EP Parameters: "  -NoNewline
$xmlEPParametersElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("EPParameters"));
$xmlEPParametersElement.SetAttribute("UpdateEPParameters","True")
$xmlEPParametersComment = $xmlDoc.CreateComment("The feature updates the EP Parameters. If empty and set to TRUE, then the BI Configuration will be deleted")
$xmlEPParametersElementComment = $xmlServersElement.InsertAfter($xmlEPParametersComment,$xmlEPSitesElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM EPGLOBALPARAMETERS" -ServerInstance $server -Database $database

if ($($result.COUNT) -eq 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT * FROM EPGLOBALPARAMETERS" -ServerInstance $server -Database $database

    $xmlEPParamHomeSiteElement = $xmlEPParametersElement.AppendChild($xmlDoc.CreateElement("HOMEPAGESITEID"));
    $xmlEPParamHomeSiteTextNode = $xmlEPParamHomeSiteElement.AppendChild($xmlDoc.CreateTextNode($($result.HOMEPAGESITEID)));

    $xmlEPParamDevElement = $xmlEPParametersElement.AppendChild($xmlDoc.CreateElement("DEVELOPMENTSITEID"));
    $xmlEPParamDevTextNode = $xmlEPParamDevElement.AppendChild($xmlDoc.CreateTextNode($($result.DEVELOPMENTSITEID)));

    $xmlEPParamSearchElement = $xmlEPParametersElement.AppendChild($xmlDoc.CreateElement("SEARCHSERVERURL"));
    $xmlEPParamSearchTextNode = $xmlEPParamSearchElement.AppendChild($xmlDoc.CreateTextNode($($result.SEARCHSERVERURL)));

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"   
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
}

#SERVERS/Document Management======================

Write-Host "-Document Management: "  -NoNewline

$xmlDocumentManagementElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("DocumentManagement"));
$xmlDocumentManagementElement.SetAttribute("UpdateDocumentManagement","True")
$xmlDocumentManagementComment = $xmlDoc.CreateComment("The feature updates the Document Handling configuration per legal entity. If empty and set to TRUE, then DM configuration will be deleted.")
$xmlDocumentManagementElementComment = $xmlServersElement.InsertAfter($xmlDocumentManagementComment,$xmlEPParametersElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM DOCUPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT ARCHIVEPATH, KEY_,ACTIVETABLE, MAXFILESIZEINDATABASE, MAXFILESIZEINFILESYSTEM, SUBMITTOWORKFLOW, DATAAREAID FROM DOCUPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlDMElement = $xmlDocumentManagementElement.AppendChild($xmlDoc.CreateElement("DM"));
      $xmlDMElement.SetAttribute("DATAAREAID",$($Item.DATAAREAID))

      $xmlDMArchivePathElement = $xmlDMElement.AppendChild($xmlDoc.CreateElement("ARCHIVEPATH"));
      $xmlDMArchivePathTextNode = $xmlDMArchivePathElement.AppendChild($xmlDoc.CreateTextNode($($Item.ARCHIVEPATH)));
      $xmlDMKeyElement = $xmlDMElement.AppendChild($xmlDoc.CreateElement("KEY_"));
      $xmlDMKeyNameTextNode = $xmlDMKeyElement.AppendChild($xmlDoc.CreateTextNode($($Item.KEY_)));
      $xmlDMActiveTableElement = $xmlDMElement.AppendChild($xmlDoc.CreateElement("ACTIVETABLE"));
      $xmlDMActiveTableTextNode = $xmlDMActiveTableElement.AppendChild($xmlDoc.CreateTextNode($($Item.ACTIVETABLE)));

      $xmlDMMaxSizeDBElement = $xmlDMElement.AppendChild($xmlDoc.CreateElement("MAXFILESIZEINDATABASE"));
      $xmlDMMaxSizeDBTextNode = $xmlDMMaxSizeDBElement.AppendChild($xmlDoc.CreateTextNode($($Item.MAXFILESIZEINDATABASE)));

      $xmlDMMaxSizeSysElement = $xmlDMElement.AppendChild($xmlDoc.CreateElement("MAXFILESIZEINFILESYSTEM"));
      $xmlDMMaxSizeSysTextNode = $xmlDMMaxSizeSysElement.AppendChild($xmlDoc.CreateTextNode($($Item.MAXFILESIZEINFILESYSTEM)));

      $xmlDMWorkflowElement = $xmlDMElement.AppendChild($xmlDoc.CreateElement("SUBMITTOWORKFLOW"));
      $xmlDMWorkflowTextNode = $xmlDMWorkflowElement.AppendChild($xmlDoc.CreateTextNode($($Item.SUBMITTOWORKFLOW)));
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
  Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

#SERVERS/SharePoint Document Management======================

Write-Host "-SharePoint Document Management: "  -NoNewline

$xmlSPDocumentManagementElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("SharePointDocumentManagement"));
$xmlSPDocumentManagementElement.SetAttribute("UpdateSharePointDocumentManagement","True")
$xmlSPDocumentManagementComment = $xmlDoc.CreateComment("The feature updates the SharePoint Document Handling configuration per legal entity. If empty and set to TRUE, then the SharePoint DM configuration will be deleted.")
$xmlSPDocumentManagementElementComment = $xmlServersElement.InsertAfter($xmlSPDocumentManagementComment,$xmlDocumentManagementElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM DOCUSHAREPOINTPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT AUTHENTICATIONTYPE, URL, DATAAREAID FROM DOCUSHAREPOINTPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlSPDMElement = $xmlSPDocumentManagementElement.AppendChild($xmlDoc.CreateElement("SharePointDM"));
      $xmlSPDMElement.SetAttribute("DATAAREAID",$($Item.DATAAREAID))

      $xmlSPDMURLElement = $xmlSPDMElement.AppendChild($xmlDoc.CreateElement("URL"));
      $xmlSPDMURLTextNode = $xmlSPDMURLElement.AppendChild($xmlDoc.CreateTextNode($($Item.URL)));
      $xmlSPDMAuthElement = $xmlSPDMElement.AppendChild($xmlDoc.CreateElement("AUTHENTICATIONTYPE"));
      $xmlSPDMAuthTextNode = $xmlSPDMAuthElement.AppendChild($xmlDoc.CreateTextNode($($Item.AUTHENTICATIONTYPE)));
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
  Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

#SERVERS/AIF Web Sites======================

Write-Host "-AIF Web Sites: "  -NoNewline

$xmlAIFWebSitesElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("AIFWebSites"));
$xmlAIFWebSitesElement.SetAttribute("UpdateAIFWebSite","True")
$xmlAIFWebSitesComment = $xmlDoc.CreateComment("The feature updates AIF Web sites. If empty and set to TRUE, then AIF web sites will be deleted.")
$xmlAIFWebSitesElementComment = $xmlServersElement.InsertAfter($xmlAIFWebSitesComment,$xmlSPDocumentManagementElement)

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM AIFWEBSITES" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT DESCRIPTION, VIRTUALDIRECTORYSHARE,NAME, URL FROM AIFWEBSITES" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
      $xmlAIFWebSiteElement = $xmlAIFWebSitesElement.AppendChild($xmlDoc.CreateElement("AIFWebSite"));
      $xmlAIFWebSiteElement.SetAttribute("NAME",$($Item.NAME))
      $xmlAIFDescriptionElement = $xmlAIFWebSiteElement.AppendChild($xmlDoc.CreateElement("DESCRIPTION"));
      $xmlAIFDescriptionTextNode = $xmlAIFDescriptionElement.AppendChild($xmlDoc.CreateTextNode($($Item.DESCRIPTION)));
      $xmlAIFDirectoryElement = $xmlAIFWebSiteElement.AppendChild($xmlDoc.CreateElement("VIRTUALDIRECTORYSHARE"));
      $xmlAIFDirectoryTextNode = $xmlAIFDirectoryElement.AppendChild($xmlDoc.CreateTextNode($($Item.VIRTUALDIRECTORYSHARE)));
      $xmlAIFUrlElement = $xmlAIFWebSiteElement.AppendChild($xmlDoc.CreateElement("URL"));
      $xmlAIFUrlTextNode = $xmlAIFUrlElement.AppendChild($xmlDoc.CreateTextNode($($Item.URL)));
    }
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
  Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }


#SERVERS/Management Reporter======================

Write-Host "-Management Reporter URLs: "  -NoNewline

$xmlManagementReporterElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("ManagementReporter"));
$xmlManagementReporterElement.SetAttribute("UpdateManagementReporter","True")
$xmlManagementReporterComment = $xmlDoc.CreateComment("The feature updates the Management Reporter URL configuration per legal entity. If empty and set to TRUE, then MR URL will be deleted.")
$xmlManagementReporterElementComment = $xmlServersElement.InsertAfter($xmlManagementReporterComment,$xmlAIFWebSitesElement)


$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM LEDGERPARAMETERS WHERE MANAGEMENTREPORTERURL != ''" -ServerInstance $server -Database $database

if ($($result.COUNT) -ge 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT TOP 1 MANAGEMENTREPORTERURL FROM LEDGERPARAMETERS WHERE MANAGEMENTREPORTERURL != ''" -ServerInstance $server -Database $database
    $MRServer = $($result.MANAGEMENTREPORTERURL) 
    $MRServer = $MRServer.Substring($MRServer.IndexOf("http://"))
    $MRServer = $MRServer -replace 'http://', ''
    $MRServer = $MRServer.Substring(0,$MRServer.IndexOf(":"))

    $xmlManagementReporterElement.SetAttribute("Server",$MRServer)


    $result = Invoke-Sqlcmd -Query "SELECT MANAGEMENTREPORTERURL, DATAAREAID FROM LEDGERPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $server -Database $database

    foreach($item in $result)
    {
        $xmlMRElement = $xmlManagementReporterElement.AppendChild($xmlDoc.CreateElement("MR"));
        $xmlMRElement.SetAttribute("DATAAREAID",$($Item.DATAAREAID))

        $xmlMRURLElement = $xmlMRElement.AppendChild($xmlDoc.CreateElement("MANAGEMENTREPORTERURL"));
        $xmlMRURLTextNode = $xmlMRURLElement.AppendChild($xmlDoc.CreateTextNode($($Item.MANAGEMENTREPORTERURL)));
   
    }
        Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

 #SERVERS/Version Control======================

Write-Host "-Version Control: "  -NoNewline

$xmlVersionControlElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("VersionControl"));
$xmlVersionControlElement.SetAttribute("UpdateVersionControl","True")
$xmlVersionControlComment = $xmlDoc.CreateComment("The feature updates the Version Control configuration.")
$xmlVersionControlElementComment = $xmlServersElement.InsertAfter($xmlVersionControlComment,$xmlManagementReporterElement)


$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM SYSVERSIONCONTROLPARAMETERS WHERE KEY_=0" -ServerInstance $server -Database $database

if ($($result.COUNT) -eq 1)
{
    $result = Invoke-Sqlcmd -Query "SELECT * FROM SYSVERSIONCONTROLPARAMETERS WHERE KEY_=0 " -ServerInstance $server -Database $database

    $xmlVCTFSServerElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("TFSServer"));
    $xmlVCTFSServerTextNode = $xmlVCTFSServerElement.AppendChild($xmlDoc.CreateTextNode($($result.TFSServer)));
    $xmlVCRepositoryFolderElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("RepositoryFolder"));
    $xmlVCRepositoryFolderTextNode = $xmlVCRepositoryFolderElement.AppendChild($xmlDoc.CreateTextNode($($result.RepositoryFolder)));
    $xmlVCEnabledElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("VCSEnabled"));
    $xmlVCEnabledTextNode = $xmlVCEnabledElement.AppendChild($xmlDoc.CreateTextNode($($result.VCSEnabled)));
    $xmlVCTypeElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("VCSType"));
    $xmlVCTypeTextNode = $xmlVCTypeElement.AppendChild($xmlDoc.CreateTextNode($($result.VCSType)));
    $xmlVCVSSProjectRootElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("VSSProjectRoot"));
    $xmlVCVSSProjectRootTextNode = $xmlVCVSSProjectRootElement.AppendChild($xmlDoc.CreateTextNode($($result.VSSProjectRoot)));
    $xmlVCTFSProjectElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("TFSProject"));
    $xmlVCTFSProjectTextNode = $xmlVCTFSProjectElement.AppendChild($xmlDoc.CreateTextNode($($result.TFSProject)));
    $xmlVCTFSBranchElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("TFSBranch"));
    $xmlVCTFSBranchTextNode = $xmlVCTFSBranchElement.AppendChild($xmlDoc.CreateTextNode($($result.TFSBranch)));
    $xmlVCAppRootElement = $xmlVersionControlElement.AppendChild($xmlDoc.CreateElement("AppRoot"));
    $xmlVCAppRootTextNode = $xmlVCAppRootElement.AppendChild($xmlDoc.CreateTextNode($($result.AppRoot)));
   

    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }


#SERVERS/AOS Servers======================

Write-Host "-AOS Servers: "  -NoNewline

$xmlAOSServersElement = $xmlServersElement.AppendChild($xmlDoc.CreateElement("AOSServers"));

$aoscount = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM SYSSERVERCONFIG" -ServerInstance $server -Database $database

if ($($aoscount.COUNT) -ge 1)
{
    $aosresult = Invoke-Sqlcmd -Query "SELECT SERVERID FROM SYSSERVERCONFIG" -ServerInstance $server -Database $database

    foreach($item in $aosresult)
    {
        $xmlAOSServerElement = $xmlAOSServersElement.AppendChild($xmlDoc.CreateElement("AOSServer"));
        $xmlAOSServerIDElement = $xmlAOSServerElement.AppendChild($xmlDoc.CreateElement("SERVERID"));
        $xmlAOSServerIDTextNode = $xmlAOSServerIDElement.AppendChild($xmlDoc.CreateTextNode($($Item.SERVERID)));
    }
        Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
 }
 else
 {
    Write-Host -ForegroundColor Black -BackgroundColor Yellow "Not Found"
 }

#SAVE FILE===================================
Pop-Location

Write-Host -ForegroundColor White "`nSaving XML File "  -NoNewline
$xmlDoc.Save($configFile);
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"

Write-Host -ForegroundColor White "Output: $configFile `n"

#AOS STOP SERVICES===================================

$aosServersCount = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM SYSSERVERCONFIG" -ServerInstance $server -Database $database
$aosRunningServer =@()

if ($($aosServersCount.Count) -ge 1)
{
    Write-Host -ForegroundColor White "Checking AOS Status"
    
    $result = Invoke-Sqlcmd -Query "SELECT SERVERID FROM SYSSERVERCONFIG" -ServerInstance $server -Database $database

    foreach($item in $result)
    {  
        $serverID = $($Item.SERVERID)
        $aosInstanceNumber = $serverID.Substring(0,2)
        $aosServerName = $serverID.Substring(3)
        $aosInstanceName = 'AOS60$'+$aosInstanceNumber
       
        Write-Host "-Checking $aosServerName $aosInstanceName " -NoNewline

        $aosServiceState = Get-Service $aosInstanceName -ComputerName $aosServerName -erroraction 'silentlycontinue'

        if ($aosServiceState)
        {
            switch ($aosServiceState.Status)
            {
                "Running"  { $color = "Yellow"; 
                             $aosRunningServer +=,($aosServerName,$aosInstanceName,$aosServiceState.Status);
                           }
                "Stopped"  { $color = "Green"}
                 default   { $color = "Red"}
            }
      
            Write-Host -ForegroundColor Black -BackgroundColor $color $aosServiceState.Status   
                                         
        }
        else
        {
            Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found" 
        }
    }

    if ($aosRunningServer.count -ge 1) 
    {
        $aosRunningServerCount = $aosRunningServer.count
        $continue = Read-Host "`n$aosRunningServerCount AOS service is running, do you want to stop the service ? (Y/N)"

        
        if ($continue -eq "Y") {
            for($i=0; $i -lt $aosRunningServer.count; $i++)  
            {  
                $aosServerName=$aosRunningServer[$i][0]
                $aosServiceName=$aosRunningServer[$i][1]
                
                Write-Host -ForegroundColor White "Stopping AOS Service $aosServiceName on $aosServerName "

                $job = start-job -scriptblock {Get-Service $args[0] -computername $args[1] | Stop-Service -WarningAction SilentlyContinue} -ArgumentList $aosServiceName, $aosServerName
                sleep -Seconds 3
            }
            Check-ServiceStoppedStatus $aosRunningServer 
        }
    }
}

#MR STOP SERVICES===================================

Write-Host -ForegroundColor White "`nChecking MR Services Status"

$result = Invoke-Sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM LEDGERPARAMETERS WHERE MANAGEMENTREPORTERURL != ''" -ServerInstance $server -Database $database

    if ($($result.COUNT) -ge 1)
    {
        $result = Invoke-Sqlcmd -Query "SELECT TOP 1 MANAGEMENTREPORTERURL FROM LEDGERPARAMETERS WHERE MANAGEMENTREPORTERURL != ''" -ServerInstance $server -Database $database
        $MRServer = $($result.MANAGEMENTREPORTERURL) 
        $MRServer = $MRServer.Substring($MRServer.IndexOf("http://"))
        $MRServer = $MRServer -replace 'http://', ''
        $MRServer = $MRServer.Substring(0,$MRServer.IndexOf(":"))

        #Checking if Application Service is Running
        Write-Host "- Server Name: " $MRServer
        Write-Host "- Checking Application Service " -NoNewline

        $mrAppServiceState = Get-Service 'MR2012ApplicationService' -ComputerName $MRServer -erroraction 'silentlycontinue'

        if ($mrAppServiceState)
        {
            switch ($mrAppServiceState.Status)
            {
                "Running"  { $color = "Yellow"; 
                                $mrRunningServer +=,($MRServer,'MR2012ApplicationService',$mrAppServiceState.Status);
                            }
                "Stopped"  { $color = "Green"}
                    default   { $color = "Red"}
            }
      
            Write-Host -ForegroundColor Black -BackgroundColor $color $mrAppServiceState.Status   
                                         
        }
        else
        {
            Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found" 
        }

        #Checking if Process Service is Running
        Write-Host "- Checking Process Service " -NoNewline

        $mrProcServiceState = Get-Service 'MR2012ProcessService' -ComputerName $MRServer -erroraction 'silentlycontinue'

        if ($mrProcServiceState)
        {
            switch ($mrProcServiceState.Status)
            {
                "Running"  { $color = "Yellow"; 
                                $mrRunningServer +=,($MRServer,'MR2012ProcessService',$mrProcServiceState.Status);
                            }
                "Stopped"  { $color = "Green"}
                    default   { $color = "Red"}
            }
      
            Write-Host -ForegroundColor Black -BackgroundColor $color $mrProcServiceState.Status   
                                         
        }
        else
        {
            Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found" 
        }


        if ($mrRunningServer.count -ge 1) 
        {
            $mrRunningServerCount = $mrRunningServer.count
            $continue = Read-Host "`nManagement Reporter services are running, do you want to stop the services ? (Y/N)"

        
            if ($continue -eq "Y") {
                for($i=0; $i -lt $mrRunningServer.count; $i++)  
                {  
                    $mrServerName=$mrRunningServer[$i][0]
                    $mrServiceName=$mrRunningServer[$i][1]
                
                    Write-Host -ForegroundColor White "Stopping AOS Service $mrServiceName on $mrServerName "

                    $job = start-job -scriptblock {Get-Service $args[0] -computername $args[1] | Stop-Service -WarningAction SilentlyContinue} -ArgumentList $mrServiceName, $mrServerName
                    sleep -Seconds 3
                }
                Check-ServiceStoppedStatus $mrRunningServer 
            }
        }
}
else
{
Write-Host -ForegroundColor Black -BackgroundColor Yellow "`nManagement Reporter Server Name could not be found."
}

## END ===================================
Write-Host -ForegroundColor White "`nEND OF SCRIPT`n"  -NoNewline
      
