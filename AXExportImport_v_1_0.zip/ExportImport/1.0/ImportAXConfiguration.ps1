﻿<#
	.SYNOPSIS
		Imports AX 2012 server configurations and perform additional operations
		Version 1.0
		Mathieu Tessier
        http://www.mathdax.ca
        https://mathdax.codeplex.com
		
	.DESCRIPTION
        Supports AX 2012 R3
        Please run script from its root folder.
        PowerShell must be run with elevated privileges.
        Prerequisites
        - SQL Client Tools
        - db_owner on business and model databases
        - Valid configuration file
        - AX Management Utilities if you want to deploy SSRS reports (optional)
        - Local Admin on the AOS servers if you want to stop and start AOS services (optional)
        - Local Admin on the Management Reporter Server if you want to stop and start MR services (optional)
        

	.PARAMETER	file
		Mandatory parameter - reads .XML file containing environment information default path is .\Config\ENV.XML
#>
param
(
    [string]$file = $(throw '- Need parameter file')
)

$importScriptVersion = "1.0"

$configFile = $PSScriptRoot + '\Config\' + $file

Function Test-SQLConnection ($Server,$axBusinessDatabaseName) {
    $ConnectionString = "Server=$Server;Integrated Security=true;Database=$axBusinessDatabaseName;Connect Timeout=3;"
    
    TRY {
        
        $SQLConn = new-object ("Data.SqlClient.SqlConnection") $ConnectionString
        $SQLConn.Open()

        IF ($SQLConn.State -eq 'Open') {
            $SQLConn.Close();
            Write-Host -ForegroundColor Black -BackgroundColor Green "Pass"
        }
    }
    CATCH 
    {
        $SQLconn.Close();
        Write-Host -BackgroundColor Red -ForegroundColor Black "Fail"
        Exit
    }
}

Function Check-Feature ($Topic, $enabled) {
Write-Host "--$Topic "  -NoNewline

switch ($enabled)
    {
    "True"  { $color = "Green"; $status = "Enabled";}
    "False" { $color = "Yellow"; $status = "Disabled";}
    default { $color = "Red"; $status = "Error";}
    }

Write-Host -ForegroundColor $color $status
}

Function Truncate-Table ($topic, $enabled, $table) {
    if ($enabled -eq "True") 
    {
        Write-Host "--$topic " -NoNewline
        Invoke-Sqlcmd -Query "TRUNCATE TABLE $table" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        Write-Host -ForegroundColor Black -BackgroundColor Green "Done"
    }
}

Function Get-RECID ($table) {

$result = Invoke-Sqlcmd -Query "SELECT TABLEID FROM SQLDICTIONARY WHERE NAME= '$table' AND FIELDID =0" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
$tableid = $result.TABLEID

$result = Invoke-Sqlcmd -Query "SELECT NEXTVAL FROM SYSTEMSEQUENCES  WHERE TABID = '$tableid' AND NAME = 'SEQNO'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
$recid = $result.NEXTVAL

if ($recid) 
{
    return $recid
}
else

{
    write-host -ForegroundColor Black -BackgroundColor Yellow "Used fake RECID"  -NoNewline
    $fakerecid = 6000000000
    return $fakerecid
}

}

Function Update-RECID ($table, $recid) {

    #if the recid if greater or equal 600000000, it is probably a fake recid. No reason to update.
    if ($recid -le 6000000000)
    {
    $result = Invoke-Sqlcmd -Query "SELECT TABLEID FROM SQLDICTIONARY WHERE NAME= '$table' AND FIELDID =0" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    $tableid = $result.TABLEID

    Invoke-Sqlcmd -Query "UPDATE SYSTEMSEQUENCES SET NEXTVAL = $recid WHERE TABID = '$tableid' AND NAME = 'SEQNO'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    }
}

Function Check-ServiceRunningStatus ($stoppedServer) {
Write-Host -ForegroundColor White "`nStatus Update"
$stoppedServerCount = $stoppedServer.count
$maxRepeat = 160
$sleepseconds = 5

do 
    {
        Write-Host -ForegroundColor White "`nServer Stopped: "$stoppedServerCount
        Write-Host -ForegroundColor White "Status Refresh Countdown: "$maxRepeat 


        for($i=0; $i -lt $stoppedServer.count; $i++)  
        {  
            $serverName = $stoppedServer[$i][0]
            $serviceName = $stoppedServer[$i][1]
            $serviceState = $stoppedServer[$i][2]

            if ($serviceState -eq "Running") 
            {
                Write-Host "-Status Service $serviceName on $serverName " -NoNewline
                Write-Host -ForegroundColor Black -BackgroundColor Green $serviceState
            }
            else
            {       
                $serviceCurrentState = Get-Service $serviceName -ComputerName $serverName
                $stoppedServer[$i][2] = $serviceCurrentState.Status
                $newServiceState = $stoppedServer[$i][2]

                Write-Host "-Status Service $serviceName on $serverName " -NoNewline
            
                if ($newServiceState -eq "Running") 
                {        
                    $stoppedServerCount--
                    Write-Host -ForegroundColor Black -BackgroundColor Green $newServiceState
                }
                elseif ($newServiceState -eq "StartPending") 
                {

                    Write-Host -ForegroundColor Black -BackgroundColor Yellow $newServiceState 
                }
                else 
                {
                    $stoppedServerCount--
                    Write-Host -ForegroundColor Black -BackgroundColor Red $newServiceState
                }
            }
        }
        $maxRepeat--
        sleep -Seconds $sleepseconds
    }until ($stoppedServerCount -eq 0 -OR $maxRepeat -eq 0)
}

Function Check-ServiceStoppedStatus ($runningServer) {
Write-Host -ForegroundColor White "`nStatus Update"
$runningServerCount = $runningServer.count
$maxRepeat = 80
$sleepseconds = 5

do 
    {
        Write-Host -ForegroundColor White "`nServer Running: "$runningServerCount
        Write-Host -ForegroundColor White "Status Refresh Countdown: "$maxRepeat

        for($i=0; $i -lt $runningServer.count; $i++)  
        {  
            $serverName = $runningServer[$i][0]
            $serviceName = $runningServer[$i][1]
            $serviceState = $runningServer[$i][2]

            if ($serviceState -eq "Stopped") 
            {
                Write-Host "-Status Service $serviceName on $serverName " -NoNewline
                Write-Host -ForegroundColor Black -BackgroundColor Green $serviceState
            }
            else
            {
                $serviceCurrentState = Get-Service $serviceName -ComputerName $serverName
                $runningServer[$i][2] = $serviceCurrentState.Status
                $newServiceState = $runningServer[$i][2]

                Write-Host "-Status Service $serviceName on $serverName " -NoNewline

                if ($newServiceState -eq "Stopped") 
                {        
                    $runningServerCount--
                    Write-Host -ForegroundColor Black -BackgroundColor Green $newServiceState 
                }
                elseif ($newServiceState -eq "StopPending") 
                {

                    Write-Host -ForegroundColor Black -BackgroundColor Yellow $newServiceState 
                }
                else 
                {
                    $runningServerCount--
                    Write-Host -ForegroundColor Black -BackgroundColor Red $newServiceState
                }
            }
        }
        $maxRepeat--
        sleep -Seconds $sleepseconds
    }until ($runningServerCount -eq 0 -OR $maxRepeat -eq 0)
}

Function Import-AXPowerShell () {
 

    if(Test-Path "HKLM:\SOFTWARE\Microsoft\Dynamics\6.0\Setup")
    {
	    $installDir = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Dynamics\6.0\Setup" -Name InstallDir).installDir
        $modulePath = $installDir + "\ManagementUtilities\Microsoft.Dynamics.ManagementUtilities.ps1"
        if (Test-Path $modulePath)
        {
            Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
            Import-Module $modulePath
        }
        else
        {
	        Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found"
            Write-Host -ForegroundColor White "`nPlease install Microsoft Dynamics AX Management Utilities"
            Exit
        }

    }
    else
    {
	    Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found"
        Write-Host -ForegroundColor White "`nPlease install Microsoft Dynamics AX Management Utilities"
        Exit
    }
}

Function Check-PSElevated {
  $wid=[System.Security.Principal.WindowsIdentity]::GetCurrent()
  $prp=new-object System.Security.Principal.WindowsPrincipal($wid)
  $adm=[System.Security.Principal.WindowsBuiltInRole]::Administrator
  $IsAdmin=$prp.IsInRole($adm)
  if ($IsAdmin)
  {
    Write-Host -ForegroundColor Black -BackgroundColor Green "Pass"
  }
  else
  {
    Write-Host -BackgroundColor Red -ForegroundColor Black "Fail"
    Write-Host "`nPlease run PowerShell with elevated privileges`n"
    Exit
  }

}


#VALIDATION CHECKS======================
##FILE VALIDATION=======================
write-host -ForegroundColor White "`nValidation Checks"
Write-Host "Checking Configuration file " -NoNewline

if (Test-Path $configFile)
{
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
}
else
{
    Write-Host -BackgroundColor Red -ForegroundColor Black "Not Found"
    Write-Host "Path $configFile"
    Exit
} 



##MODULE VALIDATION======================
Write-Host "Checking SQL Client Tools "  -NoNewline

Push-Location

if (Get-Module -ListAvailable -Name sqlps) 
{
    Import-Module "sqlps" -DisableNameChecking
    Write-Host -ForegroundColor Black -BackgroundColor Green "Pass"
} 
else 
{
    Write-Host -BackgroundColor Red -ForegroundColor Black "Fail"
    Exit
}

##UAC Validation======================
#Check PowerShell running with elevated privileges - Start/Stop AOS Services
Write-Host "Checking if PowerShell is running with Elevated Privileges " -NoNewline 
Check-PSElevated


#XML READ CONTENT======================

Write-Host -Foreground White "`nReading XML document`n"
[xml]$XmlDocument = Get-Content -path FileSystem::$configFile



#SCRIPT VALIDATION======================

Write-Host -ForegroundColor White "Reading script version"

$xmlVersion = $XmlDocument.Configuration.version

Write-Host "XML Version: $xmlVersion"
Write-Host "Script Version: $importScriptVersion"

if ($xmlVersion -eq $importScriptVersion) 
{
    Write-Host "Script Compatibility " -NoNewline
    Write-Host -ForegroundColor Black -BackgroundColor Green "Pass"
}
else
{
    Write-Host "Script Compatibility " -NoNewline
    Write-Host -ForegroundColor Black -BackgroundColor Red "Fail"
    Exit
}

#DATABASE VALIDATION======================

$sqlserver = $XmlDocument.Configuration.SQLServer.Name
$axBusinessDatabaseName = $XmlDocument.Configuration.Databases.BusinessDatabase.Name
$axModelDatabaseName = $XmlDocument.Configuration.Databases.ModelDatabase.Name

Write-Host -ForegroundColor Yellow "`nSQL Server: $sqlserver"
Write-Host -ForegroundColor Yellow "`Business Database: $axBusinessDatabaseName"
Write-Host -ForegroundColor Yellow "`Model Database: $axModelDatabaseName"


Write-Host -ForegroundColor White "`nPlease review the SQL Server and database name above"
$continue = Read-Host 'Do you want to continue ? (Y/N)'

if ($continue -ne 'Y') {Exit}

Write-Host -ForegroundColor White "`nDatabase Connectivity"

Write-Host "-$axBusinessDatabaseName "  -NoNewline
Test-SQLConnection $sqlserver $axBusinessDatabaseName

Write-Host "-$axModelDatabaseName "  -NoNewline
Test-SQLConnection $sqlserver $axModelDatabaseName


#SQL DATABASES CONFIGURATION======================
Write-Host -ForegroundColor White "`nConfiguring Databases"

$axBusinessDatabaseRecModel = $XmlDocument.Configuration.Databases.BusinessDatabase.RecoveryModel
$axModelDatabaseRecModel = $XmlDocument.Configuration.Databases.ModelDatabase.RecoveryModel


##Business Database

Write-Host -ForegroundColor White "`nDatabase: "$axBusinessDatabaseName

Write-Host "-Configuring Recovery Model " -NoNewline
Invoke-Sqlcmd -Query "ALTER DATABASE $axBusinessDatabaseName SET RECOVERY $axBusinessDatabaseRecModel" -ServerInstance $sqlServer -Database 'Master'
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"


Write-Host "-Configuring Logical Name "
Write-Host "--ROWS " -NoNewline
$result = Invoke-Sqlcmd -Query "SELECT name FROM sys.master_files WHERE DB_NAME(database_id) = '$axBusinessDatabaseName' AND type_desc = 'ROWS'" -ServerInstance $sqlServer -Database 'Master'
$axOldBusinessDatabaseRowsLogicalName = $result.Name
$axNewBusinessDatabaseRowsLogicalName = $axBusinessDatabaseName

if ($axNewBusinessDatabaseRowsLogicalName -ne $axOldBusinessDatabaseRowsLogicalName) {
    Invoke-Sqlcmd -Query "ALTER DATABASE $axBusinessDatabaseName MODIFY FILE ( NAME = $axOldBusinessDatabaseRowsLogicalName, NEWNAME = $axNewBusinessDatabaseRowsLogicalName)" -ServerInstance $sqlServer -Database 'Master'
}
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"


Write-Host "--LOG " -NoNewline
$result = Invoke-Sqlcmd -Query "SELECT name FROM sys.master_files WHERE DB_NAME(database_id) = '$axBusinessDatabaseName' AND type_desc = 'LOG'" -ServerInstance $sqlServer -Database 'Master'
$axOldBusinessDatabaseLogLogicalName = $result.Name
$axNewBusinessDatabaseLogLogicalName = $axBusinessDatabaseName+"_log"

if ($axNewBusinessDatabaseLogLogicalName -ne $axOldBusinessDatabaseLogLogicalName) {
    Invoke-Sqlcmd -Query "ALTER DATABASE $axBusinessDatabaseName MODIFY FILE ( NAME = $axOldBusinessDatabaseLogLogicalName, NEWNAME = $axNewBusinessDatabaseLogLogicalName)" -ServerInstance $sqlServer -Database 'Master'
}
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"


##Model Database

Write-Host -ForegroundColor White "`nDatabase: "$axModelDatabaseName

Write-Host "-Configuring Recovery Model " -NoNewline
Invoke-Sqlcmd -Query "ALTER DATABASE $axModelDatabaseName SET RECOVERY $axModelDatabaseRecModel" -ServerInstance $sqlServer -Database 'Master'
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"

Write-Host "-Configuring Logical Name "
Write-Host "--ROWS " -NoNewline
$result = Invoke-Sqlcmd -Query "SELECT name FROM sys.master_files WHERE DB_NAME(database_id) = '$axModelDatabaseName' AND type_desc = 'ROWS'" -ServerInstance $sqlServer -Database 'Master'
$axOldModelDatabaseRowsLogicalName = $result.Name
$axNewModelDatabaseRowsLogicalName = $axModelDatabaseName

if ($axOldModelDatabaseRowsLogicalName -ne $axNewModelDatabaseRowsLogicalName) {
    Invoke-Sqlcmd -Query "ALTER DATABASE $axModelDatabaseName MODIFY FILE ( NAME = $axOldModelDatabaseRowsLogicalName, NEWNAME = $axNewModelDatabaseRowsLogicalName)" -ServerInstance $sqlServer -Database 'Master'
}
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"


Write-Host "--LOG " -NoNewline

$result = Invoke-Sqlcmd -Query "SELECT name FROM sys.master_files WHERE DB_NAME(database_id) = '$axModelDatabaseName' AND type_desc = 'LOG'" -ServerInstance $sqlServer -Database 'Master'
$axOldModelDatabaseLogLogicalName = $result.Name
$axNewModelDatabaseLogLogicalName = $axModelDatabaseName+"_log"


if ($axOldModelDatabaseLogLogicalName -ne $axNewModelDatabaseLogLogicalName) {
    Invoke-Sqlcmd -Query "ALTER DATABASE $axModelDatabaseName MODIFY FILE ( NAME = $axOldModelDatabaseLogLogicalName, NEWNAME = $axNewModelDatabaseLogLogicalName)" -ServerInstance $sqlServer -Database 'Master'
}
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"


#AOS STOP SERVICES======================
Write-Host -ForegroundColor White "`nChecking AOS Services Status"

$xmlAOSServersElementCount = $XmlDocument.SelectNodes("/Configuration/Servers/AOSServers").Count

if ($xmlAOSServersElementCount -gt 0)
{
    $xmlAOSServersElement = $XmlDocument.Configuration.Servers.AOSServers.AOSServer
    $aosRunningServer =@()

    foreach($item in $xmlAOSServersElement) {

        $serverID = $($Item.SERVERID)
        $aosInstanceNumber = $serverID.Substring(0,2)
        $aosServerName = $serverID.Substring(3)
        $aosInstanceName = 'AOS60$'+$aosInstanceNumber
       
        Write-Host "- Checking $aosServerName $aosInstanceName " -NoNewline

        $aosServiceState = Get-Service $aosInstanceName -ComputerName $aosServerName -erroraction 'silentlycontinue'

        if ($aosServiceState)
        {
            switch ($aosServiceState.Status)
            {
                "Running"  { $color = "Yellow"; 
                             $aosRunningServer +=,($aosServerName,$aosInstanceName,$aosServiceState.Status)
                            }
                "Stopped"  { $color = "Green"}
                    default   { $color = "Red"}
            }
      
            Write-Host -ForegroundColor Black -BackgroundColor $color $aosServiceState.Status   
                                         
        }
        else
        {
            Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found" 
        }
    }

    if ($aosRunningServer.count -ge 1) 
    {
        $aosRunningServerCount = $aosRunningServer.count
        $continue = Read-Host "`n$aosRunningServerCount AOS service is running, do you want to stop the service ? (Y/N)"

        if ($continue -eq "Y") {
            for($i=0; $i -lt $aosRunningServer.count; $i++)  
            {  
                $aosServerName=$aosRunningServer[$i][0]
                $aosServiceName=$aosRunningServer[$i][1]
                
                Write-Host -ForegroundColor White "Stopping AOS Service $aosServiceName on $aosServerName "

                $job = start-job -scriptblock {Get-Service $args[0] -computername $args[1] | Stop-Service -WarningAction SilentlyContinue} -ArgumentList $aosServiceName, $aosServerName
            
            }
            sleep -Seconds 10
            Check-ServiceStoppedStatus $aosRunningServer 
        }
    }
}
Else
{
Write-Host -ForegroundColor Black -BackgroundColor Yellow "AOS not found"
}


#PARTITION ID VALIDATION======================

$partitionid= $XmlDocument.Configuration.Global.Partition.PARTITIONID
$partitionkey= $XmlDocument.Configuration.Global.Partition.PARTITIONKEY

Write-Host -ForegroundColor White "`nChecking Partition ID $partitionid "  -NoNewline

$result = Invoke-Sqlcmd -Query "SELECT COUNT (*) as COUNT FROM PARTITIONS WHERE RECID=$partitionid and PARTITIONKEY='$partitionkey'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

if($result.Count -eq 1)
{
    Write-Host -ForegroundColor Black -BackgroundColor Green "Found"
}
else
{
    Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found"
    Exit
}


#FEATURES REVIEW======================

$newGUID = $XmlDocument.Configuration.Global.GUID.newGUID
$updateDataAreaIDLiteral= $XmlDocument.Configuration.Global.DataAreaIDLiteral.UpdateDataAreaIDLiteral
$updatePartitionLiteral= $XmlDocument.Configuration.Global.PartitionLiteral.UpdatePartitionLiteral

$truncateEventInbox = $XmlDocument.Configuration.Tables.EventInbox.TruncateEventInbox
$truncateSysDatabaseLog = $XmlDocument.Configuration.Tables.SysDatabaseLog.TruncateSysDatabaseLog
$truncateSysExceptionTable = $XmlDocument.Configuration.Tables.SysExceptionTable.TruncateSysExceptionTable
$truncateSysClientSessions = $XmlDocument.Configuration.Tables.SysClientSessions.TruncateSysClientSessions
$truncateSysServerSessions = $XmlDocument.Configuration.Tables.SysServerSessions.TruncateSysServerSessions
$truncateSysServerConfig = $XmlDocument.Configuration.Tables.SysServerConfig.TruncateSysServerConfig
$truncateSysClusterConfig = $XmlDocument.Configuration.Tables.SysClusterConfig.TruncateSysClusterConfig

$updateBatchStatus = $XmlDocument.Configuration.Batch.BatchStatus.UpdateBatchStatus
$truncateBatchServerGroup = $XmlDocument.Configuration.Batch.BatchServerGroup.TruncateBatchServerGroup
$truncateBatchServerConfig = $XmlDocument.Configuration.Batch.BatchServerConfig.TruncateBatchServerConfig
$truncateBatchHistory = $XmlDocument.Configuration.Batch.BatchHistory.TruncateBatchHistory 
$truncateBatchJobHistory = $XmlDocument.Configuration.Batch.BatchJobHistory.TruncateBatchJobHistory

$updateAdminUser = $XmlDocument.Configuration.Accounts.Admin.UpdateAdminUser
$updateBCProxyAccount = $XmlDocument.Configuration.Accounts.BCProxy.UpdateBCProxyAccount
$updateMRIntegrationAccount = $XmlDocument.Configuration.Accounts.MRIntegration.UpdateMRIntegrationAccount
$updateWorkflowAccount = $XmlDocument.Configuration.Accounts.Workflow.UpdateWorkflowAccount

$updateHelpServerURL = $XmlDocument.Configuration.Servers.HelpServer.UpdateHelpServerURL
$updateSCOMAOS = $XmlDocument.Configuration.Servers.SCOM.UpdateSCOMAOS
$updateDIXFSharedPath = $XmlDocument.Configuration.Servers.DIXF.UpdateDIXFSharedPath
$addSSRSServers = $XmlDocument.Configuration.Servers.SSRSServers.AddSSRSServers
$updateEPSite = $XmlDocument.Configuration.Servers.EPSites.UpdateEPSite
$updateEPParameters = $XmlDocument.Configuration.Servers.EPParameters.UpdateEPParameters
$updateSSASServer = $XmlDocument.Configuration.Servers.SSASServers.UpdateSSASServer
$updateSSASDatabase = $XmlDocument.Configuration.Servers.SSASDatabases.UpdateSSASDatabase
$updateBIConfig = $XmlDocument.Configuration.Servers.BIConfig.UpdateBIConfig
$updateDocumentManagement = $XmlDocument.Configuration.Servers.DocumentManagement.UpdateDocumentManagement
$updateSharePointDocumentManagement = $XmlDocument.Configuration.Servers.SharePointDocumentManagement.UpdateSharePointDocumentManagement
$updateAIFWebSite = $XmlDocument.Configuration.Servers.AIFWebSites.UpdateAIFWebSite
$updateSMTPServer = $XmlDocument.Configuration.Servers.SMTPServer.UpdateSMTPServer
$updateManagementReporter = $XmlDocument.Configuration.Servers.ManagementReporter.UpdateManagementReporter
$updateVersionControl = $XmlDocument.Configuration.Servers.VersionControl.UpdateVersionControl

Write-Host -ForegroundColor White "`nConfiguration"
Write-Host -ForegroundColor White "`n-Global"

Check-Feature 'Generate New GUID' $newGUID
Check-Feature 'Update Data Area ID Literal' $updateDataAreaIDLiteral
Check-Feature 'Update Partition Literal' $updatePartitionLiteral

Write-Host -ForegroundColor White "`n-Tables"

Check-Feature 'Truncate EventInbox Table' $truncateEventInbox
Check-Feature 'Truncate SysDatabaseLog Table' $truncateSysDatabaseLog
Check-Feature 'Truncate SysExceptionTable Table' $truncateSysExceptionTable
Check-Feature 'Truncate SysClientSessions Table' $truncateSysClientSessions
Check-Feature 'Truncate SysServerSessions Table' $truncateSysServerSessions 
Check-Feature 'Truncate SysServerConfig Table' $truncateSysServerConfig
Check-Feature 'Truncate SysClusterConfig Table' $truncateSysClusterConfig

Write-Host -ForegroundColor White "`n-Batch"

Check-Feature 'Update Batch Status' $updateBatchStatus
Check-Feature 'Truncate BatchServerGroup Table' $truncateBatchServerGroup
Check-Feature 'Truncate BatchServerConfig Table' $truncateBatchServerConfig
Check-Feature 'Truncate BatchHistory Table' $truncateBatchHistory
Check-Feature 'Truncate BatchJobHistory Table' $truncateBatchJobHistory

Write-Host -ForegroundColor White "`n-Accounts"

Check-Feature 'Update Admin user' $updateAdminUser
Check-Feature 'Update BCProxy account' $updateBCProxyAccount
Check-Feature 'Update MR Integration account' $updateMRIntegrationAccount
Check-Feature 'Update Workflow account' $updateWorkflowAccount

Write-Host -ForegroundColor White "`n-Servers"

Check-Feature 'Update Help Server URL' $updateHelpServerURL
Check-Feature 'Update SCOM AOS' $updateSCOMAOS
Check-Feature 'Update DIXF Shared Path' $updateDIXFSharedPath
Check-Feature 'Update SSRS Servers' $addSSRSServers
Check-Feature 'Update EP Sites' $updateEPSite
Check-Feature 'Update EP Parameters' $updateEPParameters
Check-Feature 'Update SSAS Server' $updateSSASServer
Check-Feature 'Update SSAS Database' $updateSSASDatabase
Check-Feature 'Update BI Configuration' $updateBIConfig
Check-Feature 'Update Document Management' $updateDocumentManagement
Check-Feature 'Update SharePoint Document Management' $updateSharePointDocumentManagement
Check-Feature 'Update SMTP Server' $updateSMTPServer
Check-Feature 'Update AIF Web Site' $updateAIFWebSite
Check-Feature 'Update Management Reporter URLs' $updateManagementReporter
Check-Feature 'Update Version Control' $updateVersionControl

Write-Host -foregroundColor White "`nPlease review the configuration above"

#IMPORT PROCESS======================

$continue = Read-Host 'Do you want to continue with the import process? (Y/N)'

if ($continue -ne 'Y') {Exit}

##GLOBAL/GUID========================

Write-Host -ForegroundColor White "`n-Global"

$guidID = $XmlDocument.Configuration.Global.GUID.GUID

if ($newGUID -eq "True")
{
    Write-host "--Generate New GUID " -NoNewline
    Invoke-Sqlcmd -Query "UPDATE SYSSQMSETTINGS SET GLOBALGUID = '$guidID'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
}

##GLOBAL/DATAAREAIDLITERAL========================

if ($updateDataAreaIDLiteral -eq "True")
{
    $dataAreaIDLiteral = $XmlDocument.Configuration.Global.DataAreaIDLiteral.DataAreaIDLiteral

    if ($dataAreaIDLiteral)
    {
        Write-host "--Updating Data Area ID Literal " -NoNewline

        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '$dataAreaIDLiteral' WHERE NAME = 'DATAAREAIDLITERAL'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
    }  
    else
    {
        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '0' WHERE NAME = 'DATAAREAIDLITERAL'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    } 
    
    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
} 

##GLOBAL/PARTITIONLITERAL========================

if ($updatePartitionLiteral -eq "True")
{
    $partitionLiteral = $XmlDocument.Configuration.Global.PartitionLiteral.PartitionLiteral

    if ($partitionLiteral)
    {
        Write-host "--Updating Partition Literal " -NoNewline

        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '$partitionLiteral' WHERE NAME = 'PARTITIONLITERAL'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
    }  
    else
    {
        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '0' WHERE NAME = 'PARTITIONLITERAL'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    } 
    
    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
} 

##TABLES========================

Write-Host -ForegroundColor White "`n-Tables"
Truncate-Table 'Truncate EventInbox Table' $truncateEventInbox 'EventInbox'
Truncate-Table 'Truncate SysDatabaseLog Table' $truncateSysDatabaseLog 'SysDatabaseLog'
Truncate-Table 'Truncate SysExceptionTable Table' $truncateSysExceptionTable 'SysExceptionTable'
Truncate-Table 'Truncate SysClientSessions Table' $truncateSysClientSessions 'SysClientSessions'
Truncate-Table 'Truncate SysServerSessions Table' $truncateSysServerSessions 'SysServerSessions'
Truncate-Table 'Truncate SysServerConfig Table' $truncateSysServerConfig 'SysServerConfig'
Truncate-Table 'Truncate SysClusterConfig Table' $truncateSysClusterConfig 'SysClusterConfig'


##BATCH========================

Write-Host -ForegroundColor White "`n-Batch"
Truncate-Table 'Truncate BatchHistory Table' $truncateBatchHistory 'BatchHistory'
Truncate-Table 'Truncate BatchServerGroup Table' $truncateBatchServerGroup 'BatchServerGroup'
Truncate-Table 'Truncate BatchServerConfig Table' $truncateBatchServerConfig 'BatchServerConfig'
Truncate-Table 'Truncate BatchJobHistory Table' $truncateBatchJobHistory 'BatchJobHistory'

if ($updateBatchStatus -eq "True")
{
    Write-host "--Updating Batch Status " -NoNewline
    Invoke-Sqlcmd -Query "DELETE FROM BATCHJOB WHERE STATUS IN (4,8)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    Invoke-Sqlcmd -Query "UPDATE BATCHJOB SET STATUS = 0 WHERE STATUS IN (1,2,5,7)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
}

##ACCOUNTS========================
##ACCOUNTS/ADMIN USER========================

if ($updateAdminUser -eq "True")
{
    Write-Host -ForegroundColor White "`n-Admin Account"

    $adminsid = $XmlDocument.Configuration.Accounts.Admin.SID
    $adminNetworkDomain = $XmlDocument.Configuration.Accounts.Admin.NETWORKDOMAIN
    $adminNetworkAlias = $XmlDocument.Configuration.Accounts.Admin.NETWORKALIAS

    if ($adminsid -ne '' -AND $adminNetworkDomain -ne '' -AND $adminNetworkAlias -ne '')
    {
        Write-host "-Updating Admin Account " -NoNewline

        Invoke-Sqlcmd -Query "UPDATE USERINFO SET SID = '$adminsid', NETWORKDOMAIN = '$adminNetworkDomain', NETWORKALIAS = '$adminNetworkAlias' WHERE PARTITION = $partitionid AND ID='Admin'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }    
} 

##ACCOUNTS/BCPROXY========================

if ($updateBCProxyAccount -eq "True")
{
    Write-host -ForeGroundColor White "`n-BCProxy Account "
    $bcproxysid = $XmlDocument.Configuration.Accounts.BCProxy.SID
    $bcproxyNetworkDomain = $XmlDocument.Configuration.Accounts.BCProxy.NETWORKDOMAIN
    $bcproxyNetworkAlias = $XmlDocument.Configuration.Accounts.BCProxy.NETWORKALIAS

    Write-host "--Removing BCProxy Account " -NoNewline

    Invoke-sqlcmd -Query "DELETE FROM SYSBCPROXYUSERACCOUNT" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    if ($bcproxysid -ne '' -OR $bcproxyNetworkDomain -ne '' -OR $bcproxyNetworkAlias -ne '')
    {
        Write-host "--Adding BCProxy Account " -NoNewline
        $recid = Get-RECID SYSBCPROXYUSERACCOUNT

        Invoke-Sqlcmd -Query "INSERT INTO SYSBCPROXYUSERACCOUNT (SID,NETWORKDOMAIN,NETWORKALIAS,RECVERSION,RECID) VALUES ('$bcproxysid','$bcproxyNetworkDomain','$bcproxyNetworkAlias',1,'$recid')" -ServerInstance $sqlServer -Database $axBusinessDatabaseName 
        
        $recid = $recid+1
        Update-RECID SYSBCPROXYUSERACCOUNT $recid
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

##ACCOUNTS/MR Integration Account========================

if ($updateMRIntegrationAccount -eq "True")
    { 
   
    Write-host -ForeGroundColor White "`n-MR Integration Account "
    
    $mrIntegrationName = $XmlDocument.Configuration.Accounts.MRIntegration.NAME
    $mrIntegrationNetworkDomain = $XmlDocument.Configuration.Accounts.MRIntegration.NETWORKDOMAIN
    $mrIntegrationNetworkAlias = $XmlDocument.Configuration.Accounts.MRIntegration.NETWORKALIAS
    $mrIntegrationSID = $XmlDocument.Configuration.Accounts.MRIntegration.SID

    #Checks if Workflow account is configured
    $result = Invoke-sqlcmd -Query "SELECT COUNT (*) AS COUNT FROM USERINFO WHERE PARTITION=$partitionid AND ID ='MRint'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
 
    #Checks if XML contains a workflow configuration
    if (($mrIntegrationNetworkDomain) -AND ($mrIntegrationNetworkAlias) -AND ($mrIntegrationSID))
    {
        if ($result.COUNT -eq 1)
        {
            Write-host "--Updating MR Integration Account " -NoNewline

            Invoke-sqlcmd -Query "UPDATE USERINFO SET NAME = '$mrIntegrationName', SID = '$mrIntegrationSID', NETWORKDOMAIN = '$mrIntegrationNetworkDomain', NETWORKALIAS = '$mrIntegrationNetworkAlias' WHERE PARTITION=$partitionid AND ID = 'MRint'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
 
        }
        else
        {
            Write-host -ForeGroundColor Black -BackgroundColor Red "--Adding MR Account is not supported"  
        }
    }

    else
    {
        Write-host "--Removing MR Integration Account " -NoNewline
        
        if ($result.COUNT -eq 1) 
        {

            Invoke-sqlcmd -Query "DELETE FROM USERINFO WHERE PARTITION=$partitionid AND ID='MRint'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

        }
        else
        {
            Write-host -ForeGroundColor Black -BackgroundColor Yellow "Not Found"
        }
    }
}


##ACCOUNTS/WORKFLOW========================

if ($updateWorkflowAccount -eq "True")
    { 
   
    Write-host -ForeGroundColor White "`n-Workflow Account "
    
    $workflowoldid = $XmlDocument.Configuration.Accounts.Workflow.ID
    $workflowName = $XmlDocument.Configuration.Accounts.Workflow.NAME
    $workflowNetworkDomain = $XmlDocument.Configuration.Accounts.Workflow.NETWORKDOMAIN
    $workflowNetworkAlias = $XmlDocument.Configuration.Accounts.Workflow.NETWORKALIAS
    $workflowSID = $XmlDocument.Configuration.Accounts.Workflow.SID

    #Checks if Workflow account is configured
    $result = Invoke-sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM SYSWORKFLOWPARAMETERS WHERE PARTITION=$partitionid AND EXECUTIONUSERID != ''" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
 
    #Checks if XML contains a workflow configuration
    if (($workflowNetworkDomain) -AND ($workflowNetworkAlias) -AND ($workflowSID))
    {
        if ($result.COUNT -eq 1)
        {
            Write-host "--Updating Workflow Account " -NoNewline

            $result = Invoke-sqlcmd -Query "SELECT EXECUTIONUSERID FROM SYSWORKFLOWPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
            $workflowid = $result.EXECUTIONUSERID

            Invoke-sqlcmd -Query "UPDATE USERINFO SET NAME = '$workflowName', SID = '$workflowSID', NETWORKDOMAIN = '$workflowNetworkDomain', NETWORKALIAS = '$workflowNetworkAlias' WHERE ID = '$workflowid'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
 
        }
        else
        {
            Write-host -ForeGroundColor Black -BackgroundColor Red "--Adding Workflow Account is not supported"  
        }
    }

    else
    {
        Write-host "--Removing Workflow Account " -NoNewline
        
        if ($result.COUNT -eq 1) 
        {
            $result = Invoke-sqlcmd -Query "SELECT EXECUTIONUSERID FROM SYSWORKFLOWPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
            $workflowid = $result.EXECUTIONUSERID

            Invoke-sqlcmd -Query "DELETE FROM USERINFO WHERE PARTITION=$partitionid AND ID='workflowid'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
            Invoke-sqlcmd -Query "DELETE FROM SYSWORKFLOWPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

            Write-host "--Removing Workflow Batch Jobs " -NoNewline
            Invoke-sqlcmd -Query "DELETE FROM BATCH WHERE DATAPARTITION='$partitionkey' AND CREATEDBY='$workflowid'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
        }
        else {
            Write-host -ForeGroundColor Black -BackgroundColor Yellow "Not Found"
        }      
    }
}


##SERVERS========================

Write-Host -ForegroundColor White "`n-Servers"

##SERVERS/HELP SERVER========================

if ($updateHelpServerURL -eq "True")
{
    Write-Host -ForegroundColor White "`n-Help Server"

    $helpServerURL = $XmlDocument.Configuration.Servers.HelpServer.URL

    if ($helpServerURL -ne '')
    {
        Write-host "--Updating Help Server URL " -NoNewline

        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '$helpServerURL' WHERE NAME = 'HelpServerLocation'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
    }  
    else
    {
        Write-host "--Removing Help Server URL " -NoNewline

        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '' WHERE NAME = 'HelpServerLocation'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    } 
    
    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
} 

##SERVERS/SCOM AOS========================

if ($updateSCOMAOS -eq "True")
{
    Write-Host -ForegroundColor White "`n-SCOM Server"

    $scomAOS = $XmlDocument.Configuration.Servers.SCOM.AOS

    if ($scomAOS -ne '')
    {
        Write-host "--Updating SCOM AOS " -NoNewline

        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '$scomAOS' WHERE NAME = 'SCOMPERFORMANCEAOS'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
    }  
    else
    {
        Invoke-Sqlcmd -Query "UPDATE SYSGLOBALCONFIGURATION SET VALUE = '' WHERE NAME = 'SCOMPERFORMANCEAOS'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    } 
    
    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
} 


##SERVERS/DIXF========================

if ($updateDIXFSharedPath -eq "True")
{

    Write-Host -ForegroundColor White "`n-DIXF Path"

    $dixfSharedPath = $XmlDocument.Configuration.Servers.DIXF.SHAREDFOLDERPATH

    Write-host "--Updating DIXF Shared Path " -NoNewline

    Invoke-Sqlcmd -Query "UPDATE DMFPARAMETERS SET SHAREDFOLDERPATH = '$dixfSharedPath' WHERE PARTITION = $partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
} 

#SERVERS/SSRS======================

if ($addSSRSServers -eq "True")
{
    Write-host -ForeGroundColor White "`n-SSRS Server"
    
    Write-host "--Removing SSRS Servers " -NoNewline

    Invoke-sqlcmd -Query "DELETE FROM SRSSERVERS" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    $xmlSSRSElement = $XmlDocument.Configuration.Servers.SSRSServers.SSRSServer


    foreach($item in $xmlSSRSElement)
    {
        $recid = Get-RECID SRSSERVERS

        Write-host "--Adding SSRS ServerID '$($Item.CONFIGURATIONID)' " -NoNewline

        Invoke-Sqlcmd -Query "INSERT INTO SRSSERVERS (SERVERID,SERVERURL,ISDEFAULTREPORTLIBRARYSERVER,AXAPTAREPORTFOLDER,DESCRIPTION,REPORTMANAGERURL,SERVERINSTANCE,AOSID,CONFIGURATIONID,ISSHAREPOINTINTEGRATED, RECVERSION,RECID)  VALUES ('$($Item.SERVERID)','$($Item.SERVERURL)','$($Item.ISDEFAULTREPORTLIBRARYSERVER)','$($Item.AXAPTAREPORTFOLDER)','$($Item.DESCRIPTION)','$($Item.REPORTMANAGERURL)','$($Item.SERVERINSTANCE)','$($Item.AOSID)','$($Item.CONFIGURATIONID)','$($Item.ISSHAREPOINTINTEGRATED)',1,'$recid')" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
        $recid = $recid+1
        
        Update-RECID SRSSERVERS $recid
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

#SERVERS/ENTERPRISE PORTAL======================

if ($updateEPSite -eq "True")
{
    Write-host -ForeGroundColor White "`n-Enterprise Portal"
    
    Write-host "--Removing Enterprise Portal Sites " -NoNewline

    Invoke-sqlcmd -Query "DELETE FROM EPWEBSITEPARAMETERS WHERE PARTITIONKEY = '$partitionkey'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    $xmlEPSitesElement = $XmlDocument.Configuration.Servers.EPSites.EPSite


    foreach($item in $xmlEPSitesElement)
    {
        Write-host "--Adding EP Sites '$($Item.INTERNALURL)' " -NoNewline

        
        $recid = Get-RECID EPWEBSITEPARAMETERS  
        Invoke-Sqlcmd -Query "INSERT INTO EPWEBSITEPARAMETERS (INTERNALURL,TYPE,SITEID,ANONYMOUSACCESS,EXTERNALURL,ENABLEENCRYPTION,ENCRYPTIONEXPIRATIONINTERVAL,IMAGERESIZE,IMAGESIZESMALL,IMAGESIZELARGE,IMAGERATIO,COMPANYINDEPENDENT,LANGUAGE,SITEINSTALLATIONTYPE,USEDEFAULTREPORTSERVER,REPORTSERVERCONFIGURATIONID,PARTITIONINDEPENDENT,PARTITIONKEY, RECVERSION,RECID)  VALUES ('$($Item.INTERNALURL)','$($Item.TYPE)','$($Item.SITEID)','$($Item.ANONYMOUSACCESS)','$($Item.EXTERNALURL)','$($Item.ENABLEENCRYPTION)','$($Item.ENCRYPTIONEXPIRATIONINTERVAL)','$($Item.IMAGERESIZE)','$($Item.IMAGESIZESMALL)','$($Item.IMAGESIZELARGE)','$($Item.IMAGERATIO)','$($Item.COMPANYINDEPENDENT)','$($Item.LANGUAGE)','$($Item.SITEINSTALLATIONTYPE)','$($Item.USEDEFAULTREPORTSERVER)','$($Item.REPORTSERVERCONFIGURATIONID)','$($Item.PARTITIONINDEPENDENT)','$partitionkey',1,'$recid')" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
        $recid = $recid+1
        Update-RECID BIANALYSISSERVER $recid

        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

#SERVERS/EP PARAMETERS======================

if ($updateEPParameters -eq "True")
{
    $epParamHome = $XmlDocument.Configuration.Servers.EPParameters.HOMEPAGESITEID
    $epParamDev = $XmlDocument.Configuration.Servers.EPParameters.DEVELOPMENTSITEID
    $epParamSearch = $XmlDocument.Configuration.Servers.EPParameters.SEARCHSERVERURL

    Write-host -ForeGroundColor White "`n-EP Parameters"

    Write-host "--Removing EP Parameters " -NoNewline
    Invoke-sqlcmd -Query "TRUNCATE TABLE EPGLOBALPARAMETERS" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    if ($epParamDev)
    {
        Write-host "--Adding EP Parameters' " -NoNewline
        
        #Insert partitionid as recid because I think it is related
        Invoke-Sqlcmd -Query "INSERT INTO EPGLOBALPARAMETERS (HOMEPAGESITEID,DEVELOPMENTSITEID,SEARCHSERVERURL,RECVERSION,RECID) VALUES ('$epParamHome','$epParamDev','$epParamSearch',1,$partitionid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

#SERVERS/SSAS SERVERS======================

if ($updateSSASServer -eq "True")
{
    Write-host -ForeGroundColor White "`n-SSAS Server"

    Write-host "--Removing SSAS Servers " -NoNewline
    Invoke-sqlcmd -Query "DELETE FROM BIANALYSISSERVER WHERE PARTITIONS=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    $xmlSSASServerElement = $XmlDocument.Configuration.Servers.SSASServers.SSASServer

    foreach($item in $xmlSSASServerElement)
    {
        Write-host "--Adding SSAS Server ID '$($Item.SERVERNAME)' " -NoNewline
        
        $recid = Get-RECID BIANALYSISSERVER   
        Invoke-Sqlcmd -Query "INSERT INTO BIANALYSISSERVER (SERVERNAME,DESCRIPTION,ISVALID,ISDEFAULT,DEFAULTDATABASENAME,PARTITIONS, RECVERSION,RECID) VALUES ('$($Item.SERVERNAME)','$($Item.DESCRIPTION)','$($Item.ISVALID)','$($Item.ISDEFAULT)','$($Item.DEFAULTDATABASENAME)',$partitionid,1,$recid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        $recid = $recid+1
        
        Update-RECID BIANALYSISSERVER $recid
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

#SERVERS/SSAS DATABASES======================

if ($updateSSASDatabase -eq "True")
{
    Write-host -ForeGroundColor White "`n-SSAS Database"

    Write-host "--Removing SSAS Databases " -NoNewline
    Invoke-sqlcmd -Query "DELETE FROM BIANALYSISSERVICESDATABASE WHERE PARTITIONS=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    $xmlSSASDatabaseElement = $XmlDocument.Configuration.Servers.SSASDatabases.SSASDatabase

    foreach($item in $xmlSSASDatabaseElement)
    {
        Write-host "--Adding SSAS Server ID '$($Item.ANALYSISSERVICESDATABASENAME)' " -NoNewline
        
        $result = Invoke-Sqlcmd -Query "SELECT RECID FROM BIANALYSISSERVER WHERE SERVERNAME = '$($Item.SERVERNAME)'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName 
        $bianalysisserver = $result.RECID
        
        $recid = Get-RECID BIANALYSISSERVICESDATABASE
        Invoke-Sqlcmd -Query "INSERT INTO BIANALYSISSERVICESDATABASE (ANALYSISSERVICESDATABASENAME,BIANALYSISSERVER,ISDEFAULT,PARTITIONS, RECVERSION,RECID) VALUES ('$($Item.ANALYSISSERVICESDATABASENAME)',$bianalysisserver,'$($Item.ISDEFAULT)',$partitionid,1,$recid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        $recid = $recid+1
        
        Update-RECID BIANALYSISSERVICESDATABASE $recid
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

#SERVERS/BI CONFIG======================

if ($updateSSASServer -eq "True")
{
    $biconfigProjectPath = $XmlDocument.Configuration.Servers.BIConfig.PROJECTPATH
    $biconfigDataSourceName = $XmlDocument.Configuration.Servers.BIConfig.DATASOURCENAME
    $biconfigConnectionString = $XmlDocument.Configuration.Servers.BIConfig.CONNECTIONSTRING
    $biCOnfigLogFilePath = $XmlDocument.Configuration.Servers.BIConfig.LOGFILEPATH
    $biconfigProjectFile = $XmlDocument.Configuration.Servers.BIConfig.PROJECTFILENAME

    Write-host -ForeGroundColor White "`n-BI Config"

    Write-host "--Removing BI Configuration " -NoNewline
    Invoke-sqlcmd -Query "DELETE FROM BICONFIGURATION WHERE RECID=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    if ($biconfigConnectionString)
    {
        Write-host "--Adding BI Configuration " -NoNewline
        
        #Insert partitionid as recid because I think it is related
        Invoke-Sqlcmd -Query "INSERT INTO BICONFIGURATION (PROJECTPATH,DATASOURCENAME,CONNECTIONSTRING,LOGFILEPATH,PROJECTFILENAME, RECVERSION,RECID) VALUES ('$biconfigProjectPath','$biconfigDataSourceName','$biconfigConnectionString','$biCOnfigLogFilePath','$biconfigProjectFile',1,$partitionid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

#SERVERS/DOCUMENT MANAGMENT======================

if ($updateDocumentManagement -eq "True")
{
    Write-host -ForeGroundColor White "`n-Document Management"

    Write-host "--Removing Document Management configuration " -NoNewline
    Invoke-sqlcmd -Query "DELETE FROM DOCUPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    

    $xmlDocumentManagementElement = $XmlDocument.Configuration.Servers.DocumentManagement.DM


    foreach($item in $xmlDocumentManagementElement)
    {
        Write-host "--Checking '$($Item.DATAAREAID)' " -NoNewline
        
        #check if the legal entity exist
        $result = Invoke-sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM DATAAREA WHERE PARTITION=$partitionid AND ID='$($Item.DATAAREAID)'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

        if ($($result.COUNT) -eq 1)
        {
            Write-host -ForeGroundColor Black -BackgroundColor Green "Found"
            Write-host "---Adding DM for '$($Item.DATAAREAID)' " -NoNewline
    
            $recid = Get-RECID DOCUPARAMETERS

            Invoke-Sqlcmd -Query "INSERT INTO DOCUPARAMETERS (ARCHIVEPATH,KEY_,MAXFILESIZEINDATABASE,MAXFILESIZEINFILESYSTEM,SUBMITTOWORKFLOW,DATAAREAID, RECVERSION,PARTITION,RECID) VALUES ('$($Item.ARCHIVEPATH)','$($Item.KEY_)','$($Item.MAXFILESIZEINDATABASE)','$($Item.MAXFILESIZEINSYSTEM)','$($Item.SUBMTTOWORKFLOW)','$($Item.DATAAREAID)',1,$partitionid,$recid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
            $recid = $recid+1
        
            Update-RECID DOCUPARAMETERS $recid
        
            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
        }
        else
        {
            Write-host -ForeGroundColor Black -BackgroundColor Yellow "Not Found in the database"
        }
    }
}

#SERVERS/SHAREPOINT DOCUMENT MANAGMENT======================

if ($updateSharePointDocumentManagement -eq "True")
{
    Write-host -ForeGroundColor White "`n-SharePoint Document Management"

    Write-host "--Removing SharePoint Document Management configuration " -NoNewline
    Invoke-sqlcmd -Query "DELETE FROM DOCUSHAREPOINTPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    

    $xmlSPDocumentManagementElement = $XmlDocument.Configuration.Servers.SharePointDocumentManagement.SharePointDM


    foreach($item in $xmlSPDocumentManagementElement)
    {
        Write-host "--Checking '$($Item.DATAAREAID)' " -NoNewline
        
        #check if the legal entity exist
        $result = Invoke-sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM DATAAREA WHERE PARTITION=$partitionid AND ID='$($Item.DATAAREAID)'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

        if ($($result.COUNT) -eq 1)
        {
            Write-host -ForeGroundColor Black -BackgroundColor Green "Found"
            Write-host "---Adding DM for '$($Item.DATAAREAID)' " -NoNewline
    
            $recid = Get-RECID DOCUSHAREPOINTPARAMETERS

            Invoke-Sqlcmd -Query "INSERT INTO DOCUSHAREPOINTPARAMETERS (URL,AUTHENTICATIONTYPE,DATAAREAID, RECVERSION,PARTITION,RECID) VALUES ('$($Item.URL)','$($Item.AUTHENTICATIONTYPE)','$($Item.DATAAREAID)',1,$partitionid,$recid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
            $recid = $recid+1
        
            Update-RECID DOCUSHAREPOINTPARAMETERS $recid
        
            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
        }
        else
        {
            Write-host -ForeGroundColor Black -BackgroundColor Yellow "Not Found in the database"
        }
    }
}


#SERVERS/AIF Web Sites======================

if ($updateAIFWebSite -eq "True")
{
    Write-host -ForeGroundColor White "`n-AIF Web Sites"

    Write-host "--Removing AIF Web Sites " -NoNewline
    Invoke-sqlcmd -Query "DELETE FROM AIFWEBSITES" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    $xmlAIFWebSitesElement = $XmlDocument.Configuration.Servers.AIFWebSites.AIFWebSite

    foreach($item in $xmlAIFWebSitesElement)
    {
        Write-host "--Adding AIF Web Site '$($Item.NAME)' " -NoNewline
        
        $recid = Get-RECID AIFWEBSITES
        Invoke-Sqlcmd -Query "INSERT INTO AIFWEBSITES (DESCRIPTION,VIRTUALDIRECTORYSHARE,NAME,URL,RECVERSION,RECID) VALUES ('$($Item.DESCRIPTION)','$($Item.VIRTUALDIRECTORYSHARE)','$($Item.NAME)','$($Item.URL)',1,$recid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        $recid = $recid+1
        
        Update-RECID AIFWEBSITES $recid
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }
}

#SERVERS/SMTP Servers======================

if ($updateSMTPServer -eq "True")
{
    Write-host -ForeGroundColor White "`n-SMTP Servers"

    Write-host "--Removing SMTP Servers " -NoNewline
    Invoke-sqlcmd -Query "DELETE FROM SYSEMAILPARAMETERS WHERE PARTITION=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"

    $xmlSMTPRelayServerName = $XmlDocument.Configuration.Servers.SMTPServer.SMTPRELAYSERVERNAME
    $xmlSMTPPortNumber = $XmlDocument.Configuration.Servers.SMTPServer.SMTPPORTNUMBER
    $xmlSMTPServerIPAddress = $XmlDocument.Configuration.Servers.SMTPServer.SMTPSERVERIPADDRESS
    $xmlSMTPMax = $XmlDocument.Configuration.Servers.SMTPServer.MAXEMAILATTACHMENTSIZE
    $xmlSMTPNtlm = $XmlDocument.Configuration.Servers.SMTPServer.NTLM
        
    if ($xmlSMTPPortNumber)
    {
        
        Write-host "--Adding SMTP Server " -NoNewline
        $recid = Get-RECID SYSEMAILPARAMETERS
        Invoke-Sqlcmd -Query "INSERT INTO SYSEMAILPARAMETERS (SMTPRELAYSERVERNAME,SMTPPORTNUMBER,SMTPSERVERIPADDRESS,MAXEMAILATTACHMENTSIZE,NTLM,RECVERSION,PARTITION,RECID) VALUES ('$xmlSMTPRelayServerName',$xmlSMTPPortNumber,'$xmlSMTPServerIPAddress','$xmlSMTPMax','$xmlSMTPNtlm',1,$partitionid,$recid)" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        $recid = $recid+1
        
        Update-RECID SYSEMAILPARAMETERS $recid
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    } 
    
}

#SERVERS/MANAGEMENT REPORTER======================

if ($updateManagementReporter -eq "True")
{
    Write-host -ForeGroundColor White "`n-Management Reporter"

    Write-host "--Removing Management Reporter configuration " -NoNewline
    Invoke-sqlcmd -Query "UPDATE LEDGERPARAMETERS SET MANAGEMENTREPORTERURL = '' WHERE PARTITION=$partitionid" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

    Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    

    $xmlManagementReporterElement = $XmlDocument.Configuration.Servers.ManagementReporter.MR


    foreach($item in $xmlManagementReporterElement)
    {
        Write-host "--Checking'$($Item.DATAAREAID)' " -NoNewline
        
        #check if the legal entity exist
        $result = Invoke-sqlcmd -Query "SELECT COUNT(*) AS COUNT FROM DATAAREA WHERE PARTITION=$partitionid AND ID='$($Item.DATAAREAID)'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName

        if ($($result.COUNT) -eq 1)
        {
            Write-host -ForeGroundColor Black -BackgroundColor Green "Found"
            Write-host "---Adding MR URL for '$($Item.DATAAREAID)' " -NoNewline
    
            Invoke-Sqlcmd -Query "UPDATE LEDGERPARAMETERS SET MANAGEMENTREPORTERURL ='$($Item.MANAGEMENTREPORTERURL)' WHERE DATAAREAID = '$($Item.DATAAREAID)'" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
            Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
        }
        else
        {
            Write-host -ForeGroundColor Black -BackgroundColor Yellow "Not Found in the Database"
        }
    }
}

#SERVERS/VERSION CONTROL======================

if ($updateVersionControl -eq "True")
{
    Write-host -ForeGroundColor White "`n-Version Control"

    $vcTFSServer = $XmlDocument.Configuration.Servers.VersionControl.TFSServer
    $vcRepositoryFolder = $XmlDocument.Configuration.Servers.VersionControl.RepositoryFolder
    $vcVCSEnabled = $XmlDocument.Configuration.Servers.VersionControl.VCSEnabled
    $vcVCSType = $XmlDocument.Configuration.Servers.VersionControl.VCSType
    $vcVSSProjectRoot = $XmlDocument.Configuration.Servers.VersionControl.VSSProjectRoot
    $vcTFSProject = $XmlDocument.Configuration.Servers.VersionControl.TFSProject
    $vcTFSBranch = $XmlDocument.Configuration.Servers.VersionControl.TFSBranch
    $vcAppRoot = $XmlDocument.Configuration.Servers.VersionControl.AppRoot

    if ($vcVCSEnabled)
    {
        Write-host "--Updating Version Control Configuration " -NoNewline

        Invoke-Sqlcmd -Query "UPDATE SYSVERSIONCONTROLPARAMETERS SET TFSServer='$vcTFSServer', RepositoryFolder='$vcRepositoryFolder', VCSEnabled=$vcVCSEnabled, VCSType=$vcVCSType, VSSProjectRoot='$vcVSSProjectRoot', TFSProject='$vcTFSProject', TFSBranch='$vcTFSBranch', AppRoot='$vcAppRoot'  WHERE KEY_=0" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
        
        Write-host -ForeGroundColor Black -BackgroundColor Green "Done"
    }  
    else
    {
        Invoke-Sqlcmd -Query "UPDATE SYSVERSIONCONTROLPARAMETERS SET VCSEnabled = 0 WHERE KEY_=0" -ServerInstance $sqlServer -Database $axBusinessDatabaseName
    } 
 }   
#END===================================
Pop-Location

Write-Host -ForegroundColor White "`n`nImport Process "  -NoNewline
Write-Host -ForegroundColor Black -BackgroundColor Green "Done"

#START AOS======================
Write-Host -ForegroundColor White "`nChecking AOS Services Status"

$xmlAOSServersElementCount = $XmlDocument.SelectNodes("/Configuration/Servers/AOSServers").Count

if ($xmlAOSServersElementCount -gt 0)
{
    $xmlAOSServersElement = $XmlDocument.Configuration.Servers.AOSServers.AOSServer
    $aosStoppedServer =@()

    foreach($item in $xmlAOSServersElement) {

        $serverID = $($Item.SERVERID)
        $aosInstanceNumber = $serverID.Substring(0,2)
        $aosServerName = $serverID.Substring(3)
        $aosInstanceName = 'AOS60$'+$aosInstanceNumber

        Write-Host "-Checking $aosServerName $aosInstanceName " -NoNewline

        $aosServiceState = Get-Service $aosInstanceName -ComputerName $aosServerName -erroraction 'silentlycontinue'

        if ($aosServiceState) {
            switch ($aosServiceState.Status) {
                "Running"  { $color = "Green"; }
                "Stopped"  { $color = "Yellow";
                             $aosStoppedServer +=,($aosServerName,$aosInstanceName,$aosServiceState.Status);
                           }
                 default   { $color = "Red"}
            }
      
            Write-Host -ForegroundColor Black -BackgroundColor $color $aosServiceState.Status   
                                        
        }
        else
        {
            Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found" 
        }
    }

    if ($aosStoppedServer.count -ge 1) 
    {
        $aosStoppedServerCount = $aosStoppedServer.count
        $continue = Read-Host "`n$aosStoppedServerCount AOS service is stopped, do you want to start the service ? (Y/N)"

        if ($continue -eq "Y") {
            for($i=0; $i -lt $aosStoppedServer.count; $i++)  
            {  
                $aosServerName=$aosStoppedServer[$i][0]
                $aosServiceName=$aosStoppedServer[$i][1]
                
                Write-Host -ForegroundColor White "Starting AOS Service $aosServiceName on $aosServerName "

                $job = start-job -scriptblock {Get-Service $args[0] -computername $args[1] | Start-Service -WarningAction SilentlyContinue} -ArgumentList $aosServiceName, $aosServerName
                sleep -Seconds 3
            }
        
            Check-ServiceRunningStatus $aosStoppedServer  
        }
    }
}
Else
{
Write-Host -ForegroundColor Black -BackgroundColor Yellow "AOS not found"
}

#START MANAGEMENT REPORTER======================
Write-Host -ForegroundColor White "`nChecking MR Services Status"

$MRServer = $XmlDocument.Configuration.Servers.ManagementReporter.Server

if ($MRServer)
{

    #Checking if Application Service is Running
    Write-Host "-Server Name: " $MRServer
    Write-Host "-Checking Application Service " -NoNewline

    $mrAppServiceState = Get-Service 'MR2012ApplicationService' -ComputerName $MRServer -erroraction 'silentlycontinue'

    if ($mrAppServiceState)
    {
        switch ($mrAppServiceState.Status)
        {
            "Running"  { $color = "Green"; }
            "Stopped"  { $color = "Yellow"
                         $mrStoppedServer +=,($MRServer,'MR2012ApplicationService',$mrAppServiceState.Status);
                       }
             default   { $color = "Red"}
        }
      
        Write-Host -ForegroundColor Black -BackgroundColor $color $mrAppServiceState.Status   
                                         
    }
    else
    {
        Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found" 
    }

        #Checking if Process Service is Stopped
        Write-Host "-Checking Process Service " -NoNewline

        $mrProcServiceState = Get-Service 'MR2012ProcessService' -ComputerName $MRServer -erroraction 'silentlycontinue'

        if ($mrProcServiceState)
        {
            switch ($mrProcServiceState.Status)
            {
                "Running"  { $color = "Green"; }
                "Stopped"  { $color = "Yellow"
                             $mrStoppedServer +=,($MRServer,'MR2012ProcessService',$mrProcServiceState.Status);
                           }
                 default   { $color = "Red"}
            }
      
            Write-Host -ForegroundColor Black -BackgroundColor $color $mrProcServiceState.Status   
                                         
        }
        else
        {
            Write-Host -ForegroundColor Black -BackgroundColor Red "Not Found" 
        }


        if ($mrStoppedServer.count -ge 1) 
        {
            $mrStoppedServerCount = $mrStoppedServer.count
            $continue = Read-Host "`nManagement Reporter services are stopped, do you want to start the services ? (Y/N)"

        
            if ($continue -eq "Y") {
                for($i=0; $i -lt $mrStoppedServer.count; $i++)  
                {  
                    $mrServerName=$mrStoppedServer[$i][0]
                    $mrServiceName=$mrStoppedServer[$i][1]
                
                    Write-Host -ForegroundColor White "Starting AOS Service $mrServiceName on $mrServerName "

                    $job = start-job -scriptblock {Get-Service $args[0] -computername $args[1] | Start-Service -WarningAction SilentlyContinue} -ArgumentList $mrServiceName, $mrServerName
                    sleep -Seconds 10
                }
                Check-ServiceRunningStatus $mrStoppedServer 
            }
        }
}
else
{
Write-Host -ForegroundColor Black -BackgroundColor Yellow "`nManagement Reporter Server Name could not be found."
}

#DEPLOY REPORTS======================

$continue = Read-Host "`nDo you want to deploy reports on all SSRS servers ? (Y/N)"

if ($continue -eq "Y")
{
  
    $xmlSSRSElement = $XmlDocument.Configuration.Servers.SSRSServers.SSRSServer
    
    Write-Host -ForegroundColor White "-Checking AX Management Utilities "  -NoNewline
    Import-AXPowerShell

    foreach($item in $xmlSSRSElement)
    {
        Publish-AXReport -Report * -ID $($Item.CONFIGURATIONID)
    }
}

## END ===================================
Write-Host -ForegroundColor White "`nEND OF SCRIPT`n"  -NoNewline